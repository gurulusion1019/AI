from core.file_processor import process_file
from core.models import ProjectContext, FileRole
from core.protocol_parser import extract_measures
from core.automapper import pass1_exact
from core.model_builder import assemble_model, export_excel
from core.visual_generator import generate_visuals


# STEP 1: Create project
ctx = ProjectContext(project_name="Real Test")
model = assemble_model(ctx)

visuals = generate_visuals(model)

print("\n===== GENERATED VISUALS =====\n")

for visual in visuals:

    print(
        f"{visual.page} | "
        f"{visual.visual_type} | "
        f"{visual.title}"
    )

# STEP 2: Load raw data
with open("sales.csv", "rb") as f:
    content = f.read()

meta, df, _ = process_file(content, "pharma_sales_new.csv", FileRole.RAW_DATA)
ctx.raw_files.append(meta)
ctx._dataframes = {meta.table_name: df}

print("Loaded:", meta.table_name, meta.row_count)

# STEP 3: Protocol
ctx.protocol_text = """
Total Revenue = sum of sale_amount
Unique Customers = count of customer_id
Average Order Value = revenue / transactions
"""

# STEP 4: Extract measures
ctx.measures = extract_measures(
    ctx.protocol_text,
    [c.name for c in meta.columns]
)

print("Measures:", [m.display_name for m in ctx.measures])

# STEP 5: Build model
model = assemble_model(ctx)

print("Model built:", len(model.tables), "tables")

# STEP 6: Export Excel
excel_bytes = export_excel(model, ctx._dataframes)

with open("output.xlsx", "wb") as f:
    f.write(excel_bytes)

print("✅ Done → output.xlsx created")