"""
visual_planner.py — AI Visual Planner for the AI Reporting Automation System.

Turns a semantic model (+ optional user visual requests written in the protocol
document OR typed into the chat prompt) into a neutral "visual plan": a list of
visual specs that a renderer maps to report.json.

Design (one engine, three modes — full request / partial / none):
    1. profile_model(model)            -> compact, JSON-able description of the data
    2. plan_visuals(profile, requests) -> Claude proposes visuals; deterministic fallback
    3. apply_guardrails(plan, profile) -> enforce the safety rules we already built:
                                          * never put a key/ID column on a value slot
                                          * donut only for low-cardinality categories
                                          * attach each measure's format string
                                          * drop visuals referencing missing fields

Everything is dataset-agnostic: no hardcoded table, column, or measure names.
The plan is format-neutral, so the SAME plan can later feed a modern-PBIR
renderer instead of legacy report.json — only the renderer changes.

Run standalone to see it work on a sample retail model:
    python visual_planner.py
If ANTHROPIC_API_KEY is set, it uses the real AI planner; otherwise it shows
the deterministic fallback plan (so you can test with or without the API).
"""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Any, Optional

logger = logging.getLogger(__name__)

CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5")
DONUT_MAX_CATEGORIES = 12          # above this a donut is unreadable -> use a bar
MAX_KPI_CARDS = 4
MAX_CHARTS = 6


# ────────────────────────────────────────────────────────────────────────────
# Stage 0 — helpers (shared with the exporter's philosophy)
# ────────────────────────────────────────────────────────────────────────────
def _is_key_like(name: str) -> bool:
    """Identifier/surrogate-key detector by name shape (any dataset)."""
    n = name.strip().lower().replace(" ", "").replace("_", "")
    return n == "id" or n.endswith("id") or n.endswith("key")


def _classify_role(col: Any) -> str:
    """
    Assign a semantic role to a column from datatype + shape — never from a
    hardcoded name list. Roles: date | key | measure_col | dimension.
    """
    name = col.name
    if getattr(col, "is_date", False) or "date" in name.lower():
        return "date"
    if getattr(col, "is_pk_candidate", False):
        return "key"
    if _is_key_like(name):
        return "key"
    if getattr(col, "is_numeric", False):
        return "measure_col"
    return "dimension"


# ────────────────────────────────────────────────────────────────────────────
# Stage 1 — Profiler
# ────────────────────────────────────────────────────────────────────────────
def profile_model(model: Any) -> dict:
    """
    Build a compact profile the AI can reason over. Sends names + stats only,
    never raw data, so it is cheap and privacy-preserving.
    """
    tables = list(getattr(model, "tables", []) or [])
    profile: dict = {"fact_table": None, "tables": [], "measures": []}

    for i, t in enumerate(tables):
        cols = []
        for c in getattr(t, "columns", []) or []:
            cols.append({
                "name": c.name,
                "role": _classify_role(c),
                "dtype": getattr(c, "dtype", "object"),
                "distinct": getattr(c, "unique_count", None),
            })
        profile["tables"].append({
            "name": t.table_name,
            "role": "fact" if i == 0 else "dimension",
            "row_count": getattr(t, "row_count", None),
            "columns": cols,
        })

    if tables:
        profile["fact_table"] = tables[0].table_name

    for m in getattr(model, "measures", []) or []:
        profile["measures"].append({
            "name": getattr(m, "display_name", None) or m.name,
            "format": getattr(m, "format_string", None) or "",
        })

    return profile


# convenience lookups over a profile ----------------------------------------
def _measure_names(profile: dict) -> list[str]:
    return [m["name"] for m in profile["measures"]]


def _measure_format(profile: dict, name: str) -> str:
    for m in profile["measures"]:
        if m["name"] == name:
            return m["format"]
    return ""


def _dim_tables(profile: dict) -> list[dict]:
    return [t for t in profile["tables"] if t["role"] == "dimension"]


def _pick_category(table: dict) -> Optional[dict]:
    """Best categorical column of a table: a non-key, non-numeric, non-date column."""
    cands = [c for c in table["columns"] if c["role"] == "dimension"]
    if not cands:
        return None
    # prefer mid cardinality (nice for charts): closest to ~15 distinct
    cands.sort(key=lambda c: abs((c["distinct"] or 15) - 15))
    top = cands[0]
    return {"table": table["name"], "column": top["name"], "distinct": top["distinct"]}


def _date_field(profile: dict) -> Optional[dict]:
    for t in profile["tables"]:
        for c in t["columns"]:
            if c["role"] == "date":
                return {"table": t["name"], "column": c["name"]}
    return None


def _cardinality(profile: dict, table: str, column: str) -> Optional[int]:
    for t in profile["tables"]:
        if t["name"] == table:
            for c in t["columns"]:
                if c["name"] == column:
                    return c["distinct"]
    return None


# ────────────────────────────────────────────────────────────────────────────
# Stage 2 — AI Planner (Claude), with deterministic fallback
# ────────────────────────────────────────────────────────────────────────────
PLANNER_SYSTEM = (
    "You are a Power BI dashboard planner. Given a data profile and any user "
    "requests, you decide which visuals to build. Return ONLY a JSON array of "
    "visual specs — no prose, no markdown fences."
)

PLANNER_PROMPT = """\
DATA PROFILE (names + stats only):
{profile}

AVAILABLE MEASURES — the `measure` field of every card/bar/line/donut MUST be
copied EXACTLY from this list. NEVER put a column name (e.g. GrossRevenue,
OrderID, Quantity) in a `measure` field — always use the measure built from it
(e.g. use "Total Gross Revenue", not "GrossRevenue"; "Total Orders", not
"OrderID"; "Total Units Sold", not "Quantity"):
{measure_list}

USER VISUAL REQUESTS (may be empty — honor these first, then fill sensible gaps):
{requests}

Rules:
- CRITICAL: the `measure` field must be one of the AVAILABLE MEASURES above,
  verbatim. Map the user's wording to the closest measure name (e.g. "revenue"
  -> "Total Net Revenue", "orders" -> "Total Orders", "units" ->
  "Total Units Sold", "margin" -> "Gross Margin %").
- CRITICAL: copy table and column names VERBATIM from the profile. The user's
  wording is only a hint (e.g. "Return Reason" -> the real "ReturnReasonCode").
- Chart category/axis must be a column with role "dimension" (or "date" for a line axis).
- Never put a column whose role is "key" or "date" in a `measure` field.
- Prefer: KPI cards for headline measures; a bar for measure-by-dimension;
  a line for measure-over-date; a donut ONLY for a dimension with few distinct
  values (<= {donut_max}); slicers for useful dimensions.
- Keep it to about {max_cards} cards and {max_charts} charts plus a few slicers.

Return a JSON array where each item is one of:
  {{"type":"card","measure":"<measure>"}}
  {{"type":"bar","measure":"<measure>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"column","measure":"<measure>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"line","measure":"<measure>","axis_table":"<t>","axis_column":"<date col>"}}
  {{"type":"area","measure":"<measure>","axis_table":"<t>","axis_column":"<date col>"}}
  {{"type":"donut","measure":"<measure>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"pie","measure":"<measure>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"treemap","measure":"<measure>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"funnel","measure":"<measure>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"stacked_bar","measure":"<m>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"stacked_column","measure":"<m>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"combo","measure":"<m>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"map","measure":"<m>","category_table":"<t>","category_column":"<geo col>"}}
  {{"type":"ribbon","measure":"<m>","category_table":"<t>","category_column":"<c>","series_table":"<t>","series_column":"<c>"}}
  {{"type":"stacked100_bar","measure":"<m>","category_table":"<t>","category_column":"<c>","series_table":"<t>","series_column":"<c>"}}
  {{"type":"gauge","measure":"<m>"}}
  {{"type":"kpi","measure":"<m>","trend_table":"<t>","trend_column":"<date col>"}}
  {{"type":"shapemap","measure":"<m>","category_table":"<t>","category_column":"<geo col>"}}
  {{"type":"decomptree","measure":"<m>","explain_by":[{{"table":"<t>","column":"<c>"}},{{"table":"<t>","column":"<c>"}}]}}
  {{"type":"scatter","x_measure":"<m>","y_measure":"<m>","category_table":"<t>","category_column":"<c>"}}
  {{"type":"table","fields":[{{"kind":"column","table":"<t>","name":"<c>"}},{{"kind":"measure","name":"<m>"}}]}}
  {{"type":"matrix","row_table":"<t>","row_column":"<c>","measures":["<m>","<m>"]}}
  {{"type":"slicer","table":"<t>","column":"<c>"}}

Visual-type guidance:
- bar/column: a measure compared across a category.
- donut/pie/treemap: share of a total across a category with FEW distinct
  values (<= {donut_max}).
- line/area: a measure over a date axis.
- scatter: needs TWO measures (x_measure and y_measure) plus a category.
- funnel: stages of a process, largest to smallest.
- stacked_bar/stacked_column: parts making up a total per category.
- ribbon/stacked100_bar: need BOTH a category AND a series column to split by.
- combo: a column chart with a line overlaid.
- map: category_column must be a geographic column (country/state/city).
- gauge: a single measure shown against a range (no category).
- kpi: a single measure with an optional date column for its trend line.
- shapemap: a measure by a geographic column (country/state/region).
- decomptree: one measure to analyze, plus several columns in explain_by to
  drill through interactively.
- table: a flat list mixing columns and measures.
- matrix: one row category with several measures.
Add "source":"user" to any visual that fulfills a user request, else "source":"ai".
Return ONLY the JSON array."""


def _call_claude_stream(prompt: str, system: str, retries: int = 1) -> Optional[str]:
    """Minimal self-contained streaming call (mirrors the exporter's pattern).

    Tuned to FAIL FAST: this runs inside a user-facing build, so we prefer a
    quick fall back to the deterministic layout over making the user wait on a
    slow/hung API. Short read timeout, single attempt by default.
    """
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key:
        return None
    try:
        import requests
    except Exception:
        logger.error("requests not available")
        return None

    import time
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    payload = {
        "model": CLAUDE_MODEL,
        "max_tokens": 4000,
        "system": system,
        "messages": [{"role": "user", "content": prompt}],
        "stream": True,
    }
    for attempt in range(retries):
        try:
            with requests.post("https://api.anthropic.com/v1/messages",
                               headers=headers, json=payload,
                               timeout=(10, 45), stream=True) as resp:
                if resp.status_code == 529:
                    resp.close(); time.sleep(2 ** attempt); continue
                if resp.status_code != 200:
                    logger.error("Planner API %s: %s", resp.status_code, resp.text[:300])
                    return None
                parts: list[str] = []
                for line in resp.iter_lines(decode_unicode=True):
                    if not line or not line.startswith("data:"):
                        continue
                    data = line[len("data:"):].strip()
                    if data == "[DONE]":
                        break
                    try:
                        evt = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    if evt.get("type") == "content_block_delta":
                        d = evt.get("delta", {})
                        if d.get("type") == "text_delta":
                            parts.append(d.get("text", ""))
                    elif evt.get("type") == "error":
                        logger.error("Planner stream error: %s", evt.get("error"))
                        return None
                return "".join(parts) or None
        except requests.RequestException as exc:
            logger.error("Planner request error (%d/%d): %s", attempt + 1, retries, exc)
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
    return None


def _parse_plan_json(raw: str) -> Optional[list]:
    """Tolerant parse of the AI's JSON array (fences / truncation salvage)."""
    cleaned = re.sub(r"```(?:json)?", "", raw).strip()
    try:
        data = json.loads(cleaned)
        return data if isinstance(data, list) else data.get("visuals")
    except json.JSONDecodeError:
        pass
    start, end = cleaned.find("["), cleaned.rfind("]")
    if start != -1 and end > start:
        try:
            return json.loads(cleaned[start:end + 1])
        except json.JSONDecodeError:
            pass
    return None


def _fallback_plan(profile: dict) -> list[dict]:
    """
    Deterministic plan when the AI is unavailable. Already role- and
    cardinality-aware, so it is safe and sensible on its own.
    """
    plan: list[dict] = []
    measures = _measure_names(profile)
    dims = _dim_tables(profile)

    # KPI cards
    for m in measures[:MAX_KPI_CARDS]:
        plan.append({"type": "card", "measure": m, "source": "ai"})

    if measures and dims:
        # Bar: first dimension × first measure
        cat = _pick_category(dims[0])
        if cat:
            plan.append({"type": "bar", "measure": measures[0],
                         "category_table": cat["table"], "category_column": cat["column"],
                         "source": "ai"})
        # Line: date × a measure
        d = _date_field(profile)
        if d:
            plan.append({"type": "line", "measure": measures[min(1, len(measures) - 1)],
                         "axis_table": d["table"], "axis_column": d["column"],
                         "source": "ai"})
        # Donut: lowest-cardinality remaining dimension (if small enough)
        ranked = []
        for dt in dims[1:]:
            c = _pick_category(dt)
            if c:
                ranked.append((c["distinct"] or 9999, c))
        ranked.sort(key=lambda x: x[0])
        if ranked and ranked[0][0] <= DONUT_MAX_CATEGORIES:
            c = ranked[0][1]
            plan.append({"type": "donut", "measure": measures[min(2, len(measures) - 1)],
                         "category_table": c["table"], "category_column": c["column"],
                         "source": "ai"})

    # Slicers for up to 3 dimensions
    for dt in dims[:3]:
        c = _pick_category(dt)
        if c:
            plan.append({"type": "slicer", "table": c["table"], "column": c["column"],
                         "source": "ai"})
    return plan


def plan_visuals(profile: dict, user_requests: str = "") -> list[dict]:
    """
    Produce a visual plan. Tries the AI planner; falls back to the deterministic
    plan if the API is unavailable or returns something unusable.
    """
    prompt = PLANNER_PROMPT.format(
        profile=json.dumps(profile, indent=2)[:9000],
        measure_list="\n".join(f"  - {n}" for n in _measure_names(profile)) or "  (none)",
        requests=(user_requests.strip() or "(none)"),
        donut_max=DONUT_MAX_CATEGORIES,
        max_cards=MAX_KPI_CARDS, max_charts=MAX_CHARTS,
    )
    raw = _call_claude_stream(prompt, PLANNER_SYSTEM)
    if raw:
        plan = _parse_plan_json(raw)
        if plan:
            logger.info("AI planner produced %d visuals", len(plan))
            return plan
        logger.error("AI plan unparseable; using fallback. head=%r", raw[:200])
    else:
        logger.info("No AI response; using deterministic fallback plan")
    return _fallback_plan(profile)


# ────────────────────────────────────────────────────────────────────────────
# Stage 3 — Guardrails (the AI proposes, the rules dispose)
# ────────────────────────────────────────────────────────────────────────────
def _norm(s: str) -> str:
    """Normalize a name for tolerant matching: lowercase, strip non-alphanumerics."""
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def _resolve(candidate: str, options: list[str]) -> Optional[str]:
    """
    Map a loose name the AI produced (often from the user's protocol wording,
    e.g. 'Return Reason', 'Net Revenue') to the REAL name in the model
    (e.g. 'ReturnReasonCode', 'Total Net Revenue'). Dataset-agnostic — uses no
    hardcoded names, only string similarity against what actually exists.

    Order: exact -> normalized-exact -> substring -> token overlap. Returns the
    best real name, or None if nothing is close enough.
    """
    if not candidate or not options:
        return None
    # 1) exact
    if candidate in options:
        return candidate
    cn = _norm(candidate)
    # 2) normalized exact
    for o in options:
        if _norm(o) == cn:
            return o
    # 3) substring (either direction) on normalized forms
    sub = [o for o in options if cn and (cn in _norm(o) or _norm(o) in cn)]
    if len(sub) == 1:
        return sub[0]
    # 4) token overlap (Jaccard), with a substring boost
    ctoks = set(re.findall(r"[a-z0-9]+", candidate.lower()))
    best, best_score = None, 0.0
    for o in (sub or options):
        otoks = set(re.findall(r"[a-z0-9]+", o.lower()))
        if not otoks:
            continue
        score = len(ctoks & otoks) / max(len(ctoks | otoks), 1)
        if cn and (cn in _norm(o) or _norm(o) in cn):
            score += 0.5
        if score > best_score:
            best, best_score = o, score
    return best if best_score >= 0.5 else None


_SYNONYMS = {          # generic business word associations (not dataset-specific)
    "qty": "units", "quantity": "units", "sales": "revenue",
    "rev": "revenue", "cnt": "count", "amount": "revenue",
}


def _tokens(s: str) -> list[str]:
    """Tokenize a name, splitting camelCase and adding light business synonyms
    so 'OrderID' -> [order, id] and 'Quantity' -> [quantity, units]."""
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", s or "")
    toks = re.findall(r"[a-z0-9]+", s.lower())
    out = []
    for t in toks:
        out.append(t)
        if t in _SYNONYMS:
            out.append(_SYNONYMS[t])
    return out


def _resolve_measure(candidate: str, measure_names: list[str]) -> Optional[str]:
    """
    Resolve a measure name. Handles the common failure where the AI puts a raw
    COLUMN in the measure slot (GrossRevenue, OrderID, Quantity) instead of the
    measure built from it — by mapping via intent to a real measure. Falls back
    to fuzzy matching, and returns None (drop) if nothing is close.

    Intent hints are generic word associations, NOT dataset-specific names, so
    they generalise across datasets.
    """
    # direct fuzzy first (covers 'Net Revenue' -> 'Total Net Revenue')
    r = _resolve(candidate, measure_names)
    if r:
        return r
    # intent: shared tokens between the column-ish candidate and measure names,
    # with camelCase splitting + synonyms + crude singular/plural matching
    ctoks = _tokens(candidate)
    if not ctoks:
        return None
    best, best_score = None, 0.0
    for m in measure_names:
        mtoks = set(_tokens(m))
        shared = sum(1 for t in ctoks
                     if t in mtoks or t + "s" in mtoks or t.rstrip("s") in mtoks)
        score = shared / len(set(ctoks))
        if score > best_score:
            best, best_score = m, score
    return best if best_score >= 0.5 else None


def apply_guardrails(plan: list[dict], profile: dict) -> list[dict]:
    """
    Enforce safety AND resolve loose names to real model names. A bad or loosely
    named AI suggestion can never reach the user:
      * measure/column/table names are resolved to what actually exists (fuzzy)
      * a visual whose fields can't be resolved is DROPPED (not silently
        collapsed onto measure #1 — that caused duplicate cards)
      * donut with too many categories -> converted to bar
      * each measure's format string is attached
      * duplicate visuals (same type+measure+category) are de-duplicated
    """
    measure_names = _measure_names(profile)
    table_names = [t["name"] for t in profile["tables"]]

    def cols_of(table_real):
        for t in profile["tables"]:
            if t["name"] == table_real:
                return [c["name"] for c in t["columns"]]
        return []

    def resolve_field(table, column):
        """Resolve (table, column) loose names to real ones, or None."""
        rt = _resolve(table, table_names)
        if not rt:
            # column might be right but table wrong — try to find the column
            # in any table and adopt that table
            for t in profile["tables"]:
                rc = _resolve(column, [c["name"] for c in t["columns"]])
                if rc:
                    return t["name"], rc
            return None
        rc = _resolve(column, cols_of(rt))
        if not rc:
            return None
        return rt, rc

    clean: list[dict] = []
    seen: set = set()

    def add(v, dedup_key):
        if dedup_key in seen:
            return
        seen.add(dedup_key)
        clean.append(v)

    SHARE_TYPES = ("donut", "pie", "treemap")     # need low cardinality
    AXIS_TYPES  = ("line", "area")                # need a date axis
    SERIES_TYPES = ("ribbon", "stacked100_bar")   # need a series column too
    CAT_TYPES   = (("bar", "column", "stacked_bar", "stacked_column",
                    "funnel", "combo", "map", "shapemap") + SHARE_TYPES + SERIES_TYPES)
    VALUE_ONLY  = ("gauge", "kpi")                # measure only, no category

    for v in plan:
        vt = v.get("type")

        # ── slicers: resolve (table, column); drop if unresolvable ──────────
        if vt == "slicer":
            rf = resolve_field(v.get("table"), v.get("column"))
            if rf:
                v["table"], v["column"] = rf
                add(v, ("slicer", v["table"], v["column"]))
            continue

        # ── table: resolve each field independently ────────────────────────
        if vt == "table":
            out = []
            for f in (v.get("fields") or []):
                if f.get("kind") == "measure":
                    rm = _resolve_measure(f.get("name"), measure_names)
                    if rm:
                        out.append({"kind": "measure", "name": rm})
                else:
                    rf = resolve_field(f.get("table"), f.get("name"))
                    if rf:
                        out.append({"kind": "column", "table": rf[0], "name": rf[1]})
            if out:
                v["fields"] = out
                add(v, ("table", tuple(f["name"] for f in out)))
            continue

        # ── matrix: a row category plus one or more measures ───────────────
        if vt == "matrix":
            rf = resolve_field(v.get("row_table"), v.get("row_column"))
            ms = [m for m in (_resolve_measure(x, measure_names)
                              for x in (v.get("measures") or [])) if m]
            if rf and ms:
                v["row_table"], v["row_column"] = rf
                v["measures"] = ms
                add(v, ("matrix", v["row_table"], v["row_column"], tuple(ms)))
            continue

        # ── scatter: two measures plus a category ──────────────────────────
        if vt == "scatter":
            xm = _resolve_measure(v.get("x_measure"), measure_names)
            ym = _resolve_measure(v.get("y_measure"), measure_names)
            rf = resolve_field(v.get("category_table"), v.get("category_column"))
            if xm and ym and rf:
                v["x_measure"], v["y_measure"] = xm, ym
                v["category_table"], v["category_column"] = rf
                add(v, ("scatter", xm, ym, rf[0], rf[1]))
            continue

        # ── decomposition tree: one measure + several explain-by columns ───
        if vt == "decomptree":
            rm = _resolve_measure(v.get("measure"), measure_names)
            eb = []
            for f in (v.get("explain_by") or []):
                rf = resolve_field(f.get("table"), f.get("column"))
                if rf:
                    eb.append({"table": rf[0], "column": rf[1]})
            if rm and eb:
                v["measure"], v["explain_by"] = rm, eb
                v["format"] = _measure_format(profile, rm)
                add(v, ("decomptree", rm, tuple((f["table"], f["column"]) for f in eb)))
            continue

        # ── everything else needs one resolvable measure ───────────────────
        rm = _resolve_measure(v.get("measure"), measure_names)
        if not rm:
            continue                       # can't resolve -> drop, never collapse
        v["measure"] = rm
        v["format"] = _measure_format(profile, rm)

        if vt == "card":
            add(v, ("card", rm))

        elif vt in VALUE_ONLY:
            # gauge / kpi: measure only. Resolve the optional extras, drop if bad.
            for key in ("min_measure", "max_measure", "goal_measure"):
                if v.get(key):
                    r = _resolve_measure(v[key], measure_names)
                    if r:
                        v[key] = r
                    else:
                        v.pop(key, None)
            if v.get("trend_table") or v.get("trend_column"):
                rf = resolve_field(v.get("trend_table"), v.get("trend_column"))
                if rf:
                    v["trend_table"], v["trend_column"] = rf
                else:
                    v.pop("trend_table", None); v.pop("trend_column", None)
            add(v, (vt, rm))

        elif vt in AXIS_TYPES:
            rf = resolve_field(v.get("axis_table"), v.get("axis_column"))
            if not rf:
                continue
            v["axis_table"], v["axis_column"] = rf
            add(v, (vt, rm, v["axis_table"], v["axis_column"]))

        elif vt in CAT_TYPES:
            rf = resolve_field(v.get("category_table"), v.get("category_column"))
            if not rf:
                continue
            v["category_table"], v["category_column"] = rf
            if vt in SERIES_TYPES:
                sf = resolve_field(v.get("series_table"), v.get("series_column"))
                if sf:
                    v["series_table"], v["series_column"] = sf
                else:
                    v.pop("series_table", None); v.pop("series_column", None)
            if vt in SHARE_TYPES:
                card = _cardinality(profile, v["category_table"], v["category_column"])
                if card is not None and card > DONUT_MAX_CATEGORIES:
                    v["_converted_from"] = vt
                    v["type"] = "bar"      # too many slices -> readable bar
            add(v, (v["type"], rm, v["category_table"], v["category_column"]))

    return clean


def build_visual_plan(model: Any, user_requests: str = "") -> list[dict]:
    """Top-level entry: model (+requests) -> safe, render-ready visual plan."""
    profile = profile_model(model)
    plan = plan_visuals(profile, user_requests)
    return apply_guardrails(plan, profile)


# ────────────────────────────────────────────────────────────────────────────
# Standalone test harness — run:  python visual_planner.py
# ────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    from types import SimpleNamespace as NS

    def col(name, dtype, is_numeric=False, is_date=False, distinct=None, pk=False):
        return NS(name=name, dtype=dtype, is_numeric=is_numeric, is_date=is_date,
                  unique_count=distinct, is_pk_candidate=pk)

    # A sample retail model mirroring the real structure (fact = tables[0])
    fact = NS(table_name="retail_fact_orders", row_count=100, columns=[
        col("OrderID", "object", distinct=100, pk=True),
        col("DateKey", "int64", is_numeric=True, distinct=90),
        col("OrderDate", "datetime64[ns]", is_date=True, distinct=90),
        col("Quantity", "int64", is_numeric=True, distinct=12),
        col("GrossRevenue", "float64", is_numeric=True, distinct=98),
        col("NetRevenue", "float64", is_numeric=True, distinct=98),
    ])
    dim_channel = NS(table_name="retail_dim_channels", row_count=10, columns=[
        col("ChannelID", "int64", is_numeric=True, distinct=10, pk=True),
        col("ChannelName", "object", distinct=10),
    ])
    dim_customer = NS(table_name="retail_dim_customers", row_count=1660, columns=[
        col("CustomerID", "int64", is_numeric=True, distinct=1660, pk=True),
        col("CustomerName", "object", distinct=1660),
    ])
    dim_reason = NS(table_name="retail_dim_returnreasons", row_count=5, columns=[
        col("ReasonID", "int64", is_numeric=True, distinct=5, pk=True),
        col("ReturnReason", "object", distinct=5),
    ])
    measures = [
        NS(name="m1", display_name="Total Net Revenue",  format_string="$#,##0"),
        NS(name="m2", display_name="Total Orders",       format_string="#,##0"),
        NS(name="m3", display_name="Return Rate",        format_string="0.0%"),
        NS(name="m4", display_name="Total Units Sold",   format_string="#,##0"),
    ]
    model = NS(tables=[fact, dim_channel, dim_customer, dim_reason], measures=measures)

    print("\n=== PROFILE ===")
    prof = profile_model(model)
    print(json.dumps(prof, indent=2, default=str))

    print("\n=== PLAN (no user request) ===")
    plan = build_visual_plan(model)
    for v in plan:
        print(" ", json.dumps(v, default=str))

    print("\n=== PLAN (user asks: 'show a donut of revenue by customer') ===")
    plan2 = build_visual_plan(model, "show a donut of revenue by customer")
    for v in plan2:
        print(" ", json.dumps(v, default=str))
    print("\n(Note: donut-by-customer has 1660 categories -> guardrail converts it to a bar.)")