# AI Reporting Automation System

Phase 1 — Semantic model builder with chat-driven intake, automapping, protocol parsing,
error negotiation, and PDF completion report generation.

---

## Quick start

```bash
# 1. Set your Anthropic API key
export ANTHROPIC_API_KEY=sk-ant-...

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the tests
python tests/test_pipeline.py

# 4. Start the API server
python api/app.py

# 5. Try it via curl
SESSION=$(curl -s -X POST http://localhost:5000/api/session | python3 -c "import sys,json; print(json.load(sys.stdin)['session_id'])")

curl -s -X POST http://localhost:5000/api/chat/$SESSION \
  -H "Content-Type: application/json" \
  -d '{"message": "Q2 Sales Performance Report"}' | python3 -m json.tool
```

---

## Architecture

```
ai_reporting/
├── core/
│   ├── models.py            All dataclasses (ProjectContext, FileMeta, etc.)
│   ├── file_processor.py    CSV/Excel parsing + data quality checks
│   ├── automapper.py        3-pass column → PK mapping engine
│   ├── protocol_parser.py   Free-text → MeasureDefinition extraction
│   ├── model_builder.py     Semantic model assembly + Excel/JSON export
│   ├── chat_agent.py        Conversational orchestrator (state machine)
│   └── report_generator.py  PDF completion report
├── api/
│   └── app.py               Flask REST API
├── tests/
│   └── test_pipeline.py     Full test suite
└── requirements.txt
```

---

## API endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/session | Create a new project session |
| GET  | /api/session/{id} | Get session state summary |
| POST | /api/chat/{id} | Send a message (JSON or multipart with file) |
| GET  | /api/export/{id}/excel | Download Excel workbook |
| GET  | /api/export/{id}/tmdl | Download TMDL JSON |
| GET  | /api/export/{id}/audit | Download audit log JSON |
| GET  | /api/export/{id}/report | Generate and download PDF report |
| GET  | /api/health | Health check |

---

## Chat with file upload

```bash
# Upload a raw data file
curl -X POST http://localhost:5000/api/chat/$SESSION \
  -F "message=Here is my sales data" \
  -F "file=@sales_q2.csv"

# Upload a protocol document
curl -X POST http://localhost:5000/api/chat/$SESSION \
  -F "message=" \
  -F "file=@protocol.docx"
```

---

## Running without an API key

The system runs fully without an Anthropic API key. The automapping engine uses
passes 1 and 2 (exact match + fuzzy/value overlap) which require no AI.
Protocol parsing falls back to a stub that returns a sample measure.
DAX generation uses template-based formulas.

Set ANTHROPIC_API_KEY to enable pass 3 AI mapping, full protocol extraction, and
contextual DAX generation.

---

## Pipeline states

```
PROJECT_INIT → RAW_DATA → MAPPING_FILES → PROTOCOL → CLARIFY
    → MAPPING_REVIEW → ERROR_REVIEW → MODEL_BUILD → EXPORT → COMPLETE
```

Each state transition is driven by the user's chat messages. Files are uploaded
as multipart attachments. Errors surface in the chat as natural-language
negotiation — never silently.

---

## Error handling philosophy

Every data quality issue is presented to the user with:
1. Plain-language explanation of what happened
2. Quantified impact (row count, dollar value)
3. Sample data showing the affected rows
4. 2–5 resolution options with impact per option shown upfront
5. Explicit confirmation before any change is applied

All decisions are logged to an audit trail included in the exported model.

---

## Extending the system

**Add a new error type:** Define detection logic in `file_processor.py` or
`automapper.py`, create a `DataError` with `ResolutionOption` list, append to
`ctx.errors`. The chat agent's `ERROR_REVIEW` state will pick it up automatically.

**Add a new export format:** Implement a function in `model_builder.py` and add
a route in `api/app.py`.

**Add Power BI REST API publish:** Implement `publish_to_powerbi(model, token)`
in `model_builder.py`. The XMLA/REST API credentials are passed via environment
variables or the session context.

**Phase 2 (dashboards):** Read `ctx.semantic_model` and generate Power BI report
JSON using the visual type selection logic defined in the technical specification.
