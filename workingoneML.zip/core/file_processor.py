"""
core/file_processor.py
Parses uploaded CSV/Excel files into FileMeta objects.
Detects schema, types, PK candidates, and runs data quality checks.
"""
import io
import re
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import Optional

from .models import (
    FileMeta, ColumnMeta, FileRole,
    DataError, ErrorCategory, ErrorSeverity,
    ResolutionOption, ResolutionMethod
)


def _snake(name: str) -> str:
    """Convert a filename or column name to snake_case identifier."""
    name = Path(name).stem if '.' in name else name
    name = re.sub(r'[^a-zA-Z0-9_]', '_', name.strip())
    name = re.sub(r'_+', '_', name).strip('_').lower()
    return name or 'table'


def _infer_column(series: pd.Series, total_rows: int) -> ColumnMeta:
    """Build a ColumnMeta from a pandas Series."""
    non_null = series.dropna()
    null_count = int(series.isna().sum())
    unique_count = int(series.nunique())
    cardinality_pct = unique_count / total_rows if total_rows > 0 else 0.0

    # Detect type
    is_numeric = pd.api.types.is_numeric_dtype(series)
    is_date = False
    mixed_types = False

    if not is_numeric and len(non_null) > 0:
        # Try date parsing on a sample
        sample = non_null.head(20).astype(str)
        try:
            pd.to_datetime(sample, infer_datetime_format=True, errors='raise')
            is_date = True
        except Exception:
            pass

        # Detect mixed types: some parse as number, some don't
        if not is_date:
            numeric_parseable = sum(
                1 for v in sample
                if v.replace('.', '', 1).replace('-', '', 1).isdigit()
            )
            if 0 < numeric_parseable < len(sample) * 0.95:
                mixed_types = True

    sample_values = non_null.head(10).tolist()

    is_pk_candidate = (
        total_rows > 0
        and (total_rows - null_count) > 0
        and unique_count == (total_rows - null_count)   # every non-null value is unique
        and null_count <= max(1, round(total_rows * 0.05))  # tolerate a small null fraction
                                                              # (e.g. one "not applicable" placeholder row)
        and not (is_numeric and 'float' in str(series.dtype).lower())
        # real-world keys are essentially never continuous floats — this avoids
        # flagging numeric measure columns (e.g. a discount value) as join keys
        # just because they happen to be unique in a small table
    )

    return ColumnMeta(
        name=str(series.name),
        dtype=str(series.dtype),
        null_count=null_count,
        null_pct=null_count / total_rows if total_rows > 0 else 0.0,
        unique_count=unique_count,
        cardinality_pct=cardinality_pct,
        sample_values=sample_values,
        is_pk_candidate=is_pk_candidate,
        is_numeric=is_numeric,
        is_date=is_date,
        mixed_types=mixed_types,
    )


def _clean_column_names(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """
    Normalise column names: strip whitespace, deduplicate.
    Returns cleaned df and list of auto-resolve notes.
    """
    notes = []
    original = list(df.columns)
    cleaned = []
    seen = {}

    for col in original:
        c = str(col).strip()
        if c != str(col):
            notes.append(f"Whitespace stripped from column '{col}'")
        if c in seen:
            seen[c] += 1
            c = f"{c}_{seen[c]}"
            notes.append(f"Duplicate column renamed to '{c}'")
        else:
            seen[c] = 0
        cleaned.append(c)

    df.columns = cleaned
    return df, notes


def _detect_header_row(df_raw: pd.DataFrame) -> int:
    """
    Heuristic: scan first 5 rows for the most likely header.
    Returns 0-based row index.
    """
    for i in range(min(5, len(df_raw))):
        row = df_raw.iloc[i]
        str_ratio = sum(isinstance(v, str) for v in row) / len(row)
        unique_ratio = len(set(row)) / len(row)
        if str_ratio > 0.7 and unique_ratio > 0.8:
            return i
    return 0


def _check_duplicates(df: pd.DataFrame, table_name: str,
                      pk_candidates: list[str]) -> list[DataError]:
    """Detect duplicate PK values in dimension/mapping tables."""
    errors = []

    # Full row duplicates
    full_dups = df.duplicated().sum()
    if full_dups > 0:
        e = DataError(
            category=ErrorCategory.DATA_QUALITY,
            sub_type="DUPLICATE_ROWS",
            severity=ErrorSeverity.MEDIUM,
            affected_table=table_name,
            affected_column="(all columns)",
            affected_row_count=int(full_dups),
            detail=f"{full_dups} fully identical rows found in {table_name}.",
            sample_data=df[df.duplicated(keep=False)].head(5).to_dict('records'),
            options=[
                ResolutionOption('a', 'Remove exact duplicates',
                    'Drop all but one copy of each fully identical row.',
                    f'{full_dups} rows removed', full_dups, 0.0, True, True),
                ResolutionOption('b', 'Keep all — they are intentional',
                    'Retain all rows as-is. Suitable for fact tables.',
                    'No rows removed', 0, 0.0, True, False),
                ResolutionOption('c', 'Quarantine duplicates',
                    f'Move {full_dups} duplicates to {table_name}_quarantine.',
                    f'{full_dups} rows quarantined', full_dups, 0.0, True, False),
            ],
            recommended_option_id='a',
        )
        errors.append(e)

    # PK-level duplicates (more serious — causes join fan-out)
    for pk_col in pk_candidates:
        if pk_col not in df.columns:
            continue
        dup_mask = df.duplicated(subset=[pk_col], keep=False)
        dup_count = int(dup_mask.sum())
        if dup_count == 0:
            continue

        # Check if fields differ across duplicates
        dup_df = df[dup_mask]
        has_conflicts = False
        for _, grp in dup_df.groupby(pk_col):
            if grp.nunique().max() > 1:
                has_conflicts = True
                break

        sample = dup_df.head(6).to_dict('records')
        desc = (
            f"{dup_count} rows share duplicate values in primary key column "
            f"'{pk_col}' in {table_name}. "
            + ("Some duplicates have conflicting field values."
               if has_conflicts else "All duplicates are exact copies.")
        )

        e = DataError(
            category=ErrorCategory.DATA_QUALITY,
            sub_type="DUPLICATE_PK",
            severity=ErrorSeverity.HIGH,
            affected_table=table_name,
            affected_column=pk_col,
            affected_row_count=dup_count,
            detail=desc,
            sample_data=sample,
            options=[
                ResolutionOption('a', 'Keep first occurrence',
                    f'Keep earliest record per {pk_col}. Drop {dup_count - dup_df[pk_col].nunique()} duplicates.',
                    f'{dup_count - dup_df[pk_col].nunique()} rows removed', dup_count, 0.0, True, not has_conflicts),
                ResolutionOption('b', 'Keep most recent occurrence',
                    f'Keep latest record per {pk_col}. Recommended when newest data is source of truth.',
                    f'{dup_count - dup_df[pk_col].nunique()} rows removed', dup_count, 0.0, True, has_conflicts),
                ResolutionOption('c', 'Merge conflicting fields',
                    'For each duplicate group, take the latest non-null value per field.',
                    '0 rows removed, fields merged', 0, 0.0, True, False),
                ResolutionOption('d', 'Quarantine duplicates',
                    f'Move all {dup_count} duplicates to {table_name}_quarantine. Build model with clean rows only.',
                    f'{dup_count} rows quarantined', dup_count, 0.0, True, False),
                ResolutionOption('e', 'Stop — I will fix the source file',
                    'Pause processing. No changes made.',
                    'Processing paused', 0, 0.0, False, False),
            ],
            recommended_option_id='b' if has_conflicts else 'a',
        )
        errors.append(e)

    return errors


def _check_nulls_in_columns(df: pd.DataFrame, table_name: str,
                             col_metas: list[ColumnMeta]) -> list[DataError]:
    """Flag null values in columns likely to be join keys."""
    errors = []
    # Flag nulls in columns that look like FK/PK candidates (high cardinality, ID-like names)
    id_pattern = re.compile(r'(id|key|code|ref|num|no)$', re.IGNORECASE)
    for col in col_metas:
        if col.null_count == 0:
            continue
        if not (col.is_pk_candidate or id_pattern.search(col.name) or
                col.cardinality_pct > 0.5):
            continue
        if col.null_pct < 0.01:  # trivial — auto-note only
            continue

        # Estimate measure impact: sum of numeric columns for null rows
        null_mask = df[col.name].isna()
        numeric_cols = df.select_dtypes(include='number').columns.tolist()
        affected_value = 0.0
        if numeric_cols:
            affected_value = float(df.loc[null_mask, numeric_cols[0]].sum())

        e = DataError(
            category=ErrorCategory.DATA_QUALITY,
            sub_type="NULL_JOIN_KEY",
            severity=ErrorSeverity.HIGH if col.null_pct > 0.05 else ErrorSeverity.MEDIUM,
            affected_table=table_name,
            affected_column=col.name,
            affected_row_count=col.null_count,
            affected_measure_value=affected_value,
            detail=(
                f"{col.null_count} rows ({col.null_pct:.1%}) in {table_name}.{col.name} "
                f"have null values. These rows cannot be joined to any dimension table."
            ),
            sample_data=df[null_mask].head(5).to_dict('records'),
            options=[
                ResolutionOption('a', 'Exclude null-key rows',
                    f'Remove {col.null_count} rows from model. '
                    + (f'${affected_value:,.0f} excluded from measures.' if affected_value else ''),
                    f'{col.null_count} rows excluded', col.null_count, affected_value, True, False),
                ResolutionOption('b', f'Assign to "Unknown" placeholder',
                    f'Create a placeholder dimension row for null {col.name}. Totals stay complete.',
                    '0 rows removed, placeholder created', 0, 0.0, True, True),
                ResolutionOption('c', 'Keep — NULL dimension values acceptable',
                    'Rows stay in model. Dimension columns will be NULL for these rows.',
                    'No rows removed, partial breakdown', 0, 0.0, True, False),
            ],
            recommended_option_id='b',
        )
        errors.append(e)
    return errors


def _check_mixed_types(df: pd.DataFrame, table_name: str,
                       col_metas: list[ColumnMeta]) -> list[DataError]:
    errors = []
    for col in col_metas:
        if not col.mixed_types:
            continue
        e = DataError(
            category=ErrorCategory.DATA_QUALITY,
            sub_type="MIXED_TYPES",
            severity=ErrorSeverity.MEDIUM,
            affected_table=table_name,
            affected_column=col.name,
            detail=(
                f"Column {table_name}.{col.name} contains a mix of numeric and "
                f"non-numeric values (e.g. 'N/A', 'pending'). "
                f"Coercing to numeric will produce nulls for non-parseable entries."
            ),
            sample_data=[{'value': v} for v in col.sample_values[:8]],
            options=[
                ResolutionOption('a', 'Coerce to numeric — non-parseable become null',
                    'Standard approach. Non-numeric strings silently become null.',
                    f'Some nulls introduced in {col.name}', 0, 0.0, True, True),
                ResolutionOption('b', 'Keep as string',
                    'Column treated as categorical. Numeric measures on this column will need reconfiguration.',
                    'No data lost, measures may need adjustment', 0, 0.0, True, False),
                ResolutionOption('c', 'Stop — fix source file',
                    'Pause. Clean the column in the source file and re-upload.',
                    'Processing paused', 0, 0.0, False, False),
            ],
            recommended_option_id='a',
        )
        errors.append(e)
    return errors


def process_file(
    file_content: bytes,
    file_name: str,
    file_role: FileRole,
    project_id: str = "",
    sheet_name: Optional[str] = None,
) -> tuple[FileMeta, pd.DataFrame, list[DataError]]:
    """
    Main entry point. Parse a file into (FileMeta, DataFrame, [DataError]).
    The DataFrame is the cleaned version ready for mapping/modelling.
    """
    suffix = Path(file_name).suffix.lower()
    errors: list[DataError] = []
    auto_notes: list[str] = []

    # ── Load raw ────────────────────────────────────────────────────────────
    try:
        if suffix in ('.csv', '.tsv'):
            # Try multiple encodings
            for enc in ('utf-8', 'utf-8-sig', 'latin-1', 'cp1252'):
                try:
                    df_raw = pd.read_csv(
                        io.BytesIO(file_content), encoding=enc, low_memory=False
                    )
                    break
                except UnicodeDecodeError:
                    continue
        elif suffix in ('.xlsx', '.xls'):
            df_raw = pd.read_excel(
                io.BytesIO(file_content),
                sheet_name=sheet_name or 0,
                engine='openpyxl' if suffix == '.xlsx' else None,
            )
        else:
            raise ValueError(f"Unsupported file type: {suffix}")
    except Exception as exc:
        meta = FileMeta(
            file_name=file_name,
            table_name=_snake(file_name),
            file_role=file_role,
            errors_detected=[f"Could not read file: {exc}"],
        )
        e = DataError(
            category=ErrorCategory.SYSTEM,
            sub_type="UNREADABLE_FILE",
            severity=ErrorSeverity.HIGH,
            affected_table=_snake(file_name),
            detail=f"File '{file_name}' could not be read: {exc}",
            options=[
                ResolutionOption('a', 'Re-upload a corrected file',
                    'Fix the source file and upload again.',
                    'Processing paused', 0, 0.0, False, True),
            ],
            recommended_option_id='a',
        )
        return meta, pd.DataFrame(), [e]

    # ── Auto-resolve: drop fully empty trailing rows ─────────────────────
    original_len = len(df_raw)
    df_raw = df_raw.dropna(how='all')
    dropped_empty = original_len - len(df_raw)
    if dropped_empty > 0:
        auto_notes.append(f"Dropped {dropped_empty} fully empty rows")

    # ── Clean column names ───────────────────────────────────────────────
    df_raw, col_notes = _clean_column_names(df_raw)
    auto_notes.extend(col_notes)

    # ── Auto-resolve: strip whitespace from string values ───────────────
    str_cols = df_raw.select_dtypes(include='object').columns
    stripped_cols = []
    for col in str_cols:
        before = df_raw[col].copy()
        df_raw[col] = df_raw[col].str.strip()
        if not df_raw[col].equals(before):
            stripped_cols.append(col)
    if stripped_cols:
        auto_notes.append(
            f"Whitespace stripped from values in: {', '.join(stripped_cols)}"
        )

    # ── Auto-resolve: normalise currency strings to float ───────────────
    for col in str_cols:
        sample = df_raw[col].dropna().head(20).astype(str)
        currency_like = sample.str.match(r'^\$[\d,]+\.?\d*$').sum()
        if currency_like > len(sample) * 0.7:
            df_raw[col] = (
                df_raw[col].astype(str)
                .str.replace(r'[$,]', '', regex=True)
                .pipe(pd.to_numeric, errors='coerce')
            )
            auto_notes.append(f"Currency strings converted to float in '{col}'")

    total_rows = len(df_raw)
    table_name = _snake(file_name)

    # ── Build column metadata ────────────────────────────────────────────
    col_metas = [_infer_column(df_raw[col], total_rows) for col in df_raw.columns]
    pk_candidates = [c.name for c in col_metas if c.is_pk_candidate]

    # ── Data quality checks ──────────────────────────────────────────────
    errors.extend(_check_duplicates(df_raw, table_name, pk_candidates))
    errors.extend(_check_nulls_in_columns(df_raw, table_name, col_metas))
    errors.extend(_check_mixed_types(df_raw, table_name, col_metas))

    # ── Assemble FileMeta ────────────────────────────────────────────────
    meta = FileMeta(
        file_name=file_name,
        table_name=table_name,
        file_role=file_role,
        row_count=total_rows,
        col_count=len(df_raw.columns),
        file_size_mb=round(len(file_content) / 1_048_576, 2),
        columns=col_metas,
        pk_candidates=pk_candidates,
        sheet_name=str(sheet_name or ""),
        errors_detected=auto_notes,
    )

    for e in errors:
        e.project_id = project_id

    return meta, df_raw, errors


def apply_error_resolution(
    df: pd.DataFrame,
    error: DataError,
    chosen_option_id: str,
) -> tuple[pd.DataFrame, DataError]:
    """
    Apply a user's chosen resolution to the dataframe.
    Returns the mutated dataframe and the updated error record.
    """
    error.chosen_option_id = chosen_option_id
    error.user_confirmed = True
    error.resolved_at = datetime.now()

    col = error.affected_column
    table = error.affected_table

    if error.sub_type == "DUPLICATE_PK":
        if chosen_option_id == 'a':
            before = len(df)
            df = df.drop_duplicates(subset=[col], keep='first')
            error.rows_dropped = before - len(df)
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = f"Kept first occurrence per {col}. {error.rows_dropped} rows dropped."

        elif chosen_option_id == 'b':
            before = len(df)
            df = df.drop_duplicates(subset=[col], keep='last')
            error.rows_dropped = before - len(df)
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = f"Kept most recent per {col}. {error.rows_dropped} rows dropped."

        elif chosen_option_id == 'c':
            # Merge: for each duplicate group take latest non-null per field
            def merge_group(grp):
                result = {}
                for c in grp.columns:
                    non_null = grp[c].dropna()
                    result[c] = non_null.iloc[-1] if len(non_null) > 0 else np.nan
                return pd.Series(result)
            df = df.groupby(col, as_index=False).apply(merge_group).reset_index(drop=True)
            error.rows_modified = error.affected_row_count
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = f"Merged conflicting fields per {col}."

        elif chosen_option_id == 'd':
            dup_mask = df.duplicated(subset=[col], keep='first')
            error.rows_quarantined = int(dup_mask.sum())
            df = df[~dup_mask].copy()
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = (
                f"{error.rows_quarantined} duplicates quarantined to "
                f"{table}_quarantine."
            )

        elif chosen_option_id == 'e':
            error.resolution_method = ResolutionMethod.USER_SKIP
            error.resolution_notes = "User chose to fix source file. Processing paused."

    elif error.sub_type == "DUPLICATE_ROWS":
        if chosen_option_id == 'a':
            before = len(df)
            df = df.drop_duplicates(keep='first')
            error.rows_dropped = before - len(df)
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = f"Removed {error.rows_dropped} exact duplicate rows."
        elif chosen_option_id == 'b':
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = "Kept all rows — intentional duplicates confirmed."
        elif chosen_option_id == 'c':
            dup_mask = df.duplicated(keep='first')
            error.rows_quarantined = int(dup_mask.sum())
            df = df[~dup_mask].copy()
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = f"{error.rows_quarantined} duplicates quarantined."

    elif error.sub_type == "NULL_JOIN_KEY":
        null_mask = df[col].isna()
        if chosen_option_id == 'a':
            before = len(df)
            df = df[~null_mask].copy()
            error.rows_dropped = before - len(df)
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = f"Excluded {error.rows_dropped} null-key rows."
        elif chosen_option_id == 'b':
            df.loc[null_mask, col] = 'UNKNOWN'
            error.rows_modified = int(null_mask.sum())
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = (
                f"{error.rows_modified} null values remapped to 'UNKNOWN' placeholder."
            )
        elif chosen_option_id == 'c':
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = "Null-key rows kept with NULL dimension values."

    elif error.sub_type == "MIXED_TYPES":
        if chosen_option_id == 'a':
            df[col] = pd.to_numeric(df[col], errors='coerce')
            nulls_introduced = int(df[col].isna().sum())
            error.rows_modified = nulls_introduced
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = (
                f"Column '{col}' coerced to numeric. "
                f"{nulls_introduced} non-parseable values became null."
            )
        elif chosen_option_id == 'b':
            df[col] = df[col].astype(str)
            error.resolution_method = ResolutionMethod.USER_DECISION
            error.resolution_notes = f"Column '{col}' kept as string type."

    return df, error