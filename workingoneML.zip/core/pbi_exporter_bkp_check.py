"""
core/pbi_exporter.py
Power BI export engine.

Generates two artefacts from a completed SemanticModel:

1. model.bim  — Tabular Model BIM JSON (Analysis Services / Power BI Desktop)
   Import via: Power BI Desktop → "Import from local file" or XMLA endpoint.
   This is the full semantic layer: tables, columns, relationships, measures,
   hierarchies, and KPI metadata.

2. report.json — Power BI Report layout JSON (.pbir compatible)
   Auto-selects the best visual type per measure and dimension combination.
   Produces a single-page report with a title, KPI cards row, and up to 6
   data visuals (bar, line, donut, matrix, scatter, treemap) chosen from the
   model's measures and dimension tables.

3. PowerBI_Export.zip — Ready-to-import package:
   model.bim + report.json + README_IMPORT.txt with step-by-step instructions.

Usage (standalone):
    from core.pbi_exporter import export_powerbi_package
    zip_bytes = export_powerbi_package(model)
    with open("PowerBI_Export.zip", "wb") as f:
        f.write(zip_bytes)

Integration into chat_agent / model_builder:
    Call export_powerbi_package(model) in the EXPORT state handler.
"""

import json
import io
import uuid
import zipfile
import logging
from datetime import datetime
from typing import Optional
import pandas as pd

from .models import (
    SemanticModel, MeasureDefinition, Relationship,
    FileMeta, ColumnMeta, AggregationType, JoinType,
)

logger = logging.getLogger(__name__)

# Safety cap so an unusually large table doesn't blow up the BIM file size.
# Tables larger than this still get a full, working schema — just with the
# first N rows embedded rather than all of them.
MAX_EMBEDDED_ROWS = 20000


def _m_literal(value, dtype: str, is_date: bool = False) -> str:
    """Render a single cell value as an M (Power Query) literal."""
    try:
        if value is None or pd.isna(value):
            return "null"
    except (TypeError, ValueError):
        pass

    if is_date:
        try:
            ts = pd.Timestamp(value)
            if ts.hour or ts.minute or ts.second:
                return f"#datetime({ts.year},{ts.month},{ts.day},{ts.hour},{ts.minute},{ts.second})"
            return f"#date({ts.year},{ts.month},{ts.day})"
        except (TypeError, ValueError):
            return "null"   # unparseable date value — don't silently mis-type it as text

    d = dtype.lower()
    if "datetime" in d:
        ts = pd.Timestamp(value)
        return f"#datetime({ts.year},{ts.month},{ts.day},{ts.hour},{ts.minute},{ts.second})"
    if "bool" in d:
        return "true" if bool(value) else "false"
    if "int" in d:
        try:
            return str(int(value))
        except (TypeError, ValueError):
            return "null"
    if "float" in d:
        try:
            f = float(value)
        except (TypeError, ValueError):
            return "null"
        if f != f or f in (float("inf"), float("-inf")):   # NaN / Inf guard
            return "null"
        return repr(f)

    s = str(value).replace('"', '""').replace("\n", " ").replace("\r", " ")
    return f'"{s}"'


def _m_type(dtype: str, is_date: bool = False) -> str:
    """Map a pandas dtype string (+ the is_date heuristic) to an M type literal."""
    if is_date:
        return "type date"
    d = dtype.lower()
    if "datetime" in d: return "type datetime"
    if "bool" in d:     return "type logical"
    if "int" in d:      return "Int64.Type"
    if "float" in d:    return "type number"
    return "type text"


def _build_data_partition(meta: FileMeta, df: Optional[pd.DataFrame]) -> dict:
    """
    Build the 'partitions' M expression for a table. If the real DataFrame
    is available, embed the actual rows so the table has real data the
    moment it's imported — no manual "reconnect data source" step needed.
    Falls back to an empty-but-correctly-typed placeholder if no data was
    passed in (e.g. when called without dfs for a schema-only preview).
    """
    col_names = [c.name for c in meta.columns]
    dtypes = {c.name: c.dtype for c in meta.columns}
    is_date_map = {c.name: c.is_date for c in meta.columns}
    col_list_m = ", ".join(f'"{n}"' for n in col_names)

    if df is None or len(df) == 0:
        m_expr = [
            "let",
            f"    Source = Table.FromRows({{}}, {{{col_list_m}}})",
            "in",
            "    Source",
        ]
    else:
        rows = df.head(MAX_EMBEDDED_ROWS)
        row_lines = []
        n = len(rows)
        for i, (_, row) in enumerate(rows.iterrows()):
            cells = ", ".join(
                _m_literal(row[c], dtypes.get(c, "object"), is_date_map.get(c, False))
                for c in col_names
            )
            comma = "," if i < n - 1 else ""
            row_lines.append(f"        {{{cells}}}{comma}")

        type_pairs = ", ".join(
            f'{{"{n_}", {_m_type(dtypes.get(n_, "object"), is_date_map.get(n_, False))}}}'
            for n_ in col_names
        )

        m_expr = (
            ["let", "    Source = Table.FromRows({"]
            + row_lines
            + [f"    }}, {{{col_list_m}}}),",
               f"    Typed = Table.TransformColumnTypes(Source, {{{type_pairs}}})"]
            + ["in", "    Typed"]
        )

    partition = {
        "name": meta.table_name,
        "mode": "import",
        "source": {"type": "m", "expression": m_expr},
    }
    return partition


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — BIM SEMANTIC MODEL
# ─────────────────────────────────────────────────────────────────────────────

def _bim_datatype(pandas_dtype: str) -> str:
    """Map pandas dtype → BIM dataType string."""
    d = pandas_dtype.lower()
    if "int" in d:    return "int64"
    if "float" in d:  return "double"
    if "bool" in d:   return "boolean"
    if "datetime" in d: return "dateTime"
    return "string"


def _bim_format(format_string: str) -> str:
    """Map our internal format string to BIM formatString."""
    mapping = {
        "$#,##0":     "\\$#,##0",
        "$#,##0.00":  "\\$#,##0.00",
        "#,##0":      "#,##0",
        "#,##0.00":   "#,##0.00",
        "0.0%":       "0.0%",
        "0%":         "0%",
        "0.00%":      "0.00%",
    }
    return mapping.get(format_string, format_string)


def _dax_expression(measure: MeasureDefinition) -> str:
    """
    Strip the 'MeasureName = ' prefix from the stored DAX formula
    so the BIM expression field contains only the RHS.
    """
    dax = measure.dax_formula or ""
    if "=" in dax:
        return dax.split("=", 1)[1].strip()
    return dax


def _infer_display_folder(measure: MeasureDefinition) -> str:
    if measure.is_kpi:
        return "KPIs"
    ti = (measure.time_intelligence or "").upper()
    if ti in ("YTD", "MTD", "ROLLING_12M", "PRIOR_PERIOD"):
        return "Time Intelligence"
    agg = measure.aggregation
    if agg in (AggregationType.RATIO,):
        return "Ratios"
    if agg in (AggregationType.COUNT, AggregationType.COUNTD):
        return "Counts"
    return "Measures"


def _build_bim_table(meta: FileMeta, df: Optional[pd.DataFrame] = None) -> dict:
    """Build a single BIM table object from a FileMeta (+ its real data, if available)."""
    columns = []
    # Power BI allows only ONE isKey=True column per table — use first PK candidate only
    key_assigned = False
    for col in meta.columns:
        col_obj = {
            "name": col.name,
            "dataType": _bim_datatype(col.dtype),
            "isHidden": False,
            "summarizeBy": "none",
            "annotations": [
                {"name": "SummarizationSetBy", "value": "Automatic"}
            ],
        }
        # Numeric columns: let Power BI decide summarisation
        if col.is_numeric:
            col_obj["summarizeBy"] = "sum"
        # Date columns: tag with format
        if col.is_date:
            col_obj["dataType"] = "dateTime"
            col_obj["formatString"] = "General Date"
        # Only the FIRST PK candidate gets isKey=True — PBI allows max one key per table
        if col.is_pk_candidate and not key_assigned:
            col_obj["isKey"] = True
            col_obj["summarizeBy"] = "none"
            key_assigned = True
        columns.append(col_obj)

    table = {
        "name": meta.table_name,
        "columns": columns,
        "partitions": [_build_data_partition(meta, df)],
        "annotations": [
            {"name": "PBI_ResultType", "value": "Table"},
        ],
    }

    # Add row count annotation for reference
    if meta.row_count > 0:
        table["annotations"].append(
            {"name": "RowCount", "value": str(meta.row_count)}
        )

    return table


def _build_bim_measures(model: SemanticModel) -> list[dict]:
    """
    Build BIM measure objects. Measures are placed on the first raw/fact table.
    If no tables exist, returns empty list.
    """
    if not model.tables:
        return []

    measures = []
    for m in model.measures:
        expr = _dax_expression(m)
        if not expr:
            continue

        measure_obj = {
            "name": m.display_name or m.name,
            "expression": expr,
            "formatString": _bim_format(m.format_string),
            "description": m.description or "",
            "displayFolder": _infer_display_folder(m),
            "isHidden": False,
            "annotations": [
                {"name": "PBI_FormatHint", "value": f'{{"isGeneralNumber":true}}'},
            ],
        }

        # KPI metadata
        if m.is_kpi and m.kpi_target:
            measure_obj["kpi"] = {
                "targetExpression": m.kpi_target,
                "statusGraphic": "Three Symbols UnCircled Colored",
            }

        measures.append(measure_obj)

    return measures


def export_bim(model: SemanticModel, dfs: Optional[dict] = None) -> str:
    """
    Generate a Power BI / Analysis Services BIM JSON file.
    Returns JSON string ready to write to model.bim.

    dfs: optional {table_name: DataFrame} — when provided, real data is
    embedded directly into each table's M query so the model has actual
    rows the moment it's imported. Without it, tables get an empty (but
    correctly typed) placeholder that needs a manual data source.

    Import into Power BI Desktop:
      File → Import → Power BI template  (or use Tabular Editor / XMLA)
    """
    dfs = dfs or {}

    # ── Tables ──────────────────────────────────────────────────────────────
    bim_tables = []
    fact_table_name = None  # We'll attach measures to the first raw/fact table

    for meta in model.tables:
        t = _build_bim_table(meta, dfs.get(meta.table_name))
        bim_tables.append(t)
        if fact_table_name is None:
            fact_table_name = meta.table_name  # first table = measure home

    # Attach measures to the first table
    bim_measures = _build_bim_measures(model)
    if bim_measures and bim_tables:
        bim_tables[0]["measures"] = bim_measures

    # ── Date table (auto-generated if any date column found) ─────────────
    has_date_col = any(
        col.is_date
        for meta in model.tables
        for col in meta.columns
    )
    if has_date_col:
        date_table = _build_auto_date_table()
        bim_tables.append(date_table)

    # ── Relationships ────────────────────────────────────────────────────
    bim_relationships = []
    for rel in model.relationships:
        cardinality = "manyToOne"
        if rel.join_type == JoinType.ONE_TO_ONE:
            cardinality = "oneToOne"

        cross_filter_bim = (
            "bothDirections"
            if rel.cross_filter.upper() in ("BOTH", "BOTHDIRECTIONS")
            else "oneDirection"
        )

        bim_relationships.append({
            "name":             f"{rel.from_table}_{rel.from_column}_{rel.to_table}",
            "fromTable":        rel.from_table,
            "fromColumn":       rel.from_column,
            "toTable":          rel.to_table,
            "toColumn":         rel.to_column,
            "crossFilteringBehavior": cross_filter_bim,
            "isActive":         rel.is_active,
            "joinOnDateBehavior": "dateAndTime",
        })

    # ── Roles (Row-Level Security placeholder) ───────────────────────────
    roles = [
        {
            "name": "ReportViewer",
            "modelPermission": "read",
            "members": [],
            "tablePermissions": [],
        }
    ]

    # Note: deliberately no "cultures" block. A culture entry requires a
    # complete, valid linguisticMetadata schema (with a required "Language"
    # property among others) for Power BI's natural-language/Q&A engine to
    # parse — a minimal/placeholder one causes a hard error on load
    # ("Required property 'Language' not found in JSON") even though the
    # rest of the model loads fine. Cultures are optional; the model works
    # correctly without one, just without a defined Q&A linguistic schema.

    # ── Final BIM structure ───────────────────────────────────────────────
    bim = {
        "name":                  model.project_name,
        "compatibilityLevel":    1567,           # PBI Desktop current level
        "model": {
            "defaultPowerBIDataSourceVersion": "powerBI_V3",
            "sourceQueryCulture":              "en-US",
            "tables":        bim_tables,
            "relationships": bim_relationships,
            "roles":         roles,
            "annotations": [
                {"name": "PBI_QueryOrder",       "value": json.dumps([t["name"] for t in bim_tables])},
                {"name": "AutoCreatedRelationships", "value": "[]"},
                {"name": "GeneratedBy",          "value": "AI Reporting Automation System v1.0"},
                {"name": "ModelID",              "value": model.model_id},
                {"name": "ProjectID",            "value": model.project_id},
                {"name": "BuiltAt",              "value": str(model.built_at)},
            ],
        },
    }

    return json.dumps(bim, indent=2, default=str)


def _build_auto_date_table() -> dict:
    """
    Generate a standard auto date/calendar table as a calculated M table.
    Provides Year, Quarter, Month, MonthNo, Week, Day columns.
    """
    m_expr = [
        "let",
        "    StartDate = #date(2015, 1, 1),",
        "    EndDate   = #date(2030, 12, 31),",
        "    Duration  = Duration.Days(EndDate - StartDate) + 1,",
        "    Dates     = List.Dates(StartDate, Duration, #duration(1,0,0,0)),",
        "    Table     = Table.FromList(Dates, Splitter.SplitByNothing(), {\"Date\"}),",
        "    TypedDate = Table.TransformColumnTypes(Table, {{\"Date\", type date}}),",
        "    Year      = Table.AddColumn(TypedDate, \"Year\",     each Date.Year([Date]),    Int64.Type),",
        "    Quarter   = Table.AddColumn(Year,      \"Quarter\",  each \"Q\" & Text.From(Date.QuarterOfYear([Date])), type text),",
        "    MonthNo   = Table.AddColumn(Quarter,   \"MonthNo\",  each Date.Month([Date]),   Int64.Type),",
        "    Month     = Table.AddColumn(MonthNo,   \"Month\",    each Date.ToText([Date], \"MMM yyyy\"), type text),",
        "    Week      = Table.AddColumn(Month,     \"WeekNo\",   each Date.WeekOfYear([Date]), Int64.Type),",
        "    Day       = Table.AddColumn(Week,      \"DayOfWeek\",each Date.DayOfWeekName([Date]), type text),",
        "    Sorted    = Table.Sort(Day, {{\"Date\", Order.Ascending}})",
        "in",
        "    Sorted",
    ]

    return {
        "name": "dim_date",
        "columns": [
            {"name": "Date",      "dataType": "dateTime", "isKey": True,  "summarizeBy": "none", "isHidden": False},
            {"name": "Year",      "dataType": "int64",    "isKey": False, "summarizeBy": "none", "isHidden": False},
            {"name": "Quarter",   "dataType": "string",   "isKey": False, "summarizeBy": "none", "isHidden": False},
            {"name": "MonthNo",   "dataType": "int64",    "isKey": False, "summarizeBy": "none", "isHidden": True},
            {"name": "Month",     "dataType": "string",   "isKey": False, "summarizeBy": "none", "isHidden": False},
            {"name": "WeekNo",    "dataType": "int64",    "isKey": False, "summarizeBy": "none", "isHidden": False},
            {"name": "DayOfWeek", "dataType": "string",   "isKey": False, "summarizeBy": "none", "isHidden": False},
        ],
        "partitions": [
            {
                "name": "dim_date",
                "mode": "import",
                "source": {"type": "m", "expression": m_expr},
            }
        ],
        "annotations": [
            {"name": "PBI_ResultType", "value": "Table"},
            {"name": "AutoDateTable",  "value": "true"},
        ],
        "isHidden": False,
        "showAsVariationsOnly": False,
    }


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — REPORT LAYOUT (.pbir / report.json)
# ─────────────────────────────────────────────────────────────────────────────

# Canvas dimensions (Power BI default 16:9 widescreen)
CANVAS_W = 1280
CANVAS_H = 720

# Layout grid constants
MARGIN       = 20
TITLE_H      = 60
KPI_ROW_Y    = TITLE_H + MARGIN
KPI_H        = 90
VISUAL_ROW_Y = KPI_ROW_Y + KPI_H + MARGIN
VISUAL_H     = CANVAS_H - VISUAL_ROW_Y - MARGIN
VISUAL_COLS  = 3


def _new_guid() -> str:
    return str(uuid.uuid4()).upper()


def _visual_base(x: int, y: int, w: int, h: int,
                 visual_type: str, name: str) -> dict:
    """Skeleton visual container used by all visual builders."""
    return {
        "id":   _new_guid(),
        "name": name,
        "visualType": visual_type,
        "x": x, "y": y, "z": 0,
        "width": w, "height": h,
        "config": "{}",
        "filters": "[]",
        "objects": "{}",
    }


def _title_visual(project_name: str) -> dict:
    """Full-width title text box."""
    v = _visual_base(MARGIN, MARGIN, CANVAS_W - 2 * MARGIN, TITLE_H - MARGIN,
                     "textbox", "ReportTitle")
    v["config"] = {
        "singleVisual": {
            "visualType": "textbox",
            "objects": {
                "general": [{
                    "properties": {
                        "paragraphs": [{
                            "textRuns": [{
                                "value": project_name,
                                "textStyle": {
                                    "fontWeight": "bold",
                                    "fontSize": "24pt",
                                    "color": {"solid": {"color": "#0F2D52"}},
                                },
                            }],
                            "horizontalTextAlignment": "Left",
                        }]
                    }
                }]
            },
        }
    }
    return v


def _kpi_card_visual(measure: MeasureDefinition,
                     x: int, y: int, w: int, h: int,
                     fact_table: str) -> dict:
    """Single KPI card visual."""
    v = _visual_base(x, y, w, h, "card", f"kpi_{measure.name}")
    v["config"] = {
        "singleVisual": {
            "visualType": "card",
            "projections": {
                "Values": [{"queryRef": f"{fact_table}.{measure.display_name}"}]
            },
            "prototypeQuery": {
                "Select": [{
                    "Measure": {
                        "Expression": {"SourceRef": {"Source": fact_table}},
                        "Property": measure.display_name,
                    },
                    "Name": f"{fact_table}.{measure.display_name}",
                }],
                "From": [{"Name": fact_table, "Entity": fact_table}],
            },
            "objects": {
                "labels": [{"properties": {
                    "fontSize": {"expr": {"Literal": {"Value": "20D"}}},
                    "fontBold": {"expr": {"Literal": {"Value": "true"}}},
                    "color": {"solid": {"color": "#0F2D52"}},
                }}],
                "title": [{"properties": {
                    "show": {"expr": {"Literal": {"Value": "true"}}},
                    "titleText": {"expr": {"Literal": {"Value": f"'{measure.display_name}'"}}},
                    "fontSize": {"expr": {"Literal": {"Value": "9D"}}},
                    "fontColor": {"solid": {"color": "#616161"}},
                }}],
                "background": [{"properties": {
                    "show": {"expr": {"Literal": {"Value": "true"}}},
                    "color": {"solid": {"color": "#E3F2FD"}},
                    "transparency": {"expr": {"Literal": {"Value": "0D"}}},
                }}],
                "border": [{"properties": {
                    "show": {"expr": {"Literal": {"Value": "true"}}},
                    "color": {"solid": {"color": "#1565C0"}},
                    "radius": {"expr": {"Literal": {"Value": "4D"}}},
                }}],
            },
        }
    }
    return v


def _bar_chart_visual(measure: MeasureDefinition, dim_table: FileMeta,
                      dim_col: str, x: int, y: int, w: int, h: int,
                      fact_table: str) -> dict:
    """Clustered bar chart: dimension on Y-axis, measure on X-axis."""
    v = _visual_base(x, y, w, h, "barChart", f"bar_{measure.name}")
    v["config"] = {
        "singleVisual": {
            "visualType": "barChart",
            "projections": {
                "Category": [{"queryRef": f"{dim_table.table_name}.{dim_col}"}],
                "Y":        [{"queryRef": f"{fact_table}.{measure.display_name}"}],
            },
            "prototypeQuery": {
                "Select": [
                    {
                        "Column": {
                            "Expression": {"SourceRef": {"Source": dim_table.table_name}},
                            "Property": dim_col,
                        },
                        "Name": f"{dim_table.table_name}.{dim_col}",
                    },
                    {
                        "Measure": {
                            "Expression": {"SourceRef": {"Source": fact_table}},
                            "Property": measure.display_name,
                        },
                        "Name": f"{fact_table}.{measure.display_name}",
                    },
                ],
                "From": [
                    {"Name": dim_table.table_name, "Entity": dim_table.table_name},
                    {"Name": fact_table,           "Entity": fact_table},
                ],
                "OrderBy": [{
                    "Direction": 2,
                    "Expression": {
                        "Measure": {
                            "Expression": {"SourceRef": {"Source": fact_table}},
                            "Property": measure.display_name,
                        }
                    },
                }],
                "Top": {"Count": 20},
            },
            "objects": {
                "title": [{"properties": {
                    "show": {"expr": {"Literal": {"Value": "true"}}},
                    "titleText": {"expr": {"Literal": {"Value": f"'{measure.display_name} by {dim_col}'"}}},
                    "fontSize": {"expr": {"Literal": {"Value": "10D"}}},
                    "fontColor": {"solid": {"color": "#0F2D52"}},
                }}],
                "dataColors": [{"properties": {
                    "fill": {"solid": {"color": "#1565C0"}},
                }}],
            },
        }
    }
    return v


def _line_chart_visual(measure: MeasureDefinition, date_col: str,
                       date_table: str, x: int, y: int, w: int, h: int,
                       fact_table: str) -> dict:
    """Line chart: date on X-axis, measure on Y-axis."""
    v = _visual_base(x, y, w, h, "lineChart", f"line_{measure.name}")
    v["config"] = {
        "singleVisual": {
            "visualType": "lineChart",
            "projections": {
                "Category": [{"queryRef": f"{date_table}.{date_col}"}],
                "Y":        [{"queryRef": f"{fact_table}.{measure.display_name}"}],
            },
            "prototypeQuery": {
                "Select": [
                    {
                        "Column": {
                            "Expression": {"SourceRef": {"Source": date_table}},
                            "Property": date_col,
                        },
                        "Name": f"{date_table}.{date_col}",
                    },
                    {
                        "Measure": {
                            "Expression": {"SourceRef": {"Source": fact_table}},
                            "Property": measure.display_name,
                        },
                        "Name": f"{fact_table}.{measure.display_name}",
                    },
                ],
                "From": [
                    {"Name": date_table,  "Entity": date_table},
                    {"Name": fact_table,  "Entity": fact_table},
                ],
                "OrderBy": [{
                    "Direction": 1,
                    "Expression": {
                        "Column": {
                            "Expression": {"SourceRef": {"Source": date_table}},
                            "Property": date_col,
                        }
                    },
                }],
            },
            "objects": {
                "title": [{"properties": {
                    "show":      {"expr": {"Literal": {"Value": "true"}}},
                    "titleText": {"expr": {"Literal": {"Value": f"'{measure.display_name} Over Time'"}}},
                    "fontSize":  {"expr": {"Literal": {"Value": "10D"}}},
                    "fontColor": {"solid": {"color": "#0F2D52"}},
                }}],
                "line": [{"properties": {
                    "stroke":          {"solid": {"color": "#1565C0"}},
                    "strokeWidth":     {"expr": {"Literal": {"Value": "2D"}}},
                    "showMarkers":     {"expr": {"Literal": {"Value": "true"}}},
                    "markerShape":     {"expr": {"Literal": {"Value": "'circle'"}}},
                    "markerSize":      {"expr": {"Literal": {"Value": "4D"}}},
                }}],
            },
        }
    }
    return v


def _donut_chart_visual(measure: MeasureDefinition, dim_table: FileMeta,
                        dim_col: str, x: int, y: int, w: int, h: int,
                        fact_table: str) -> dict:
    """Donut chart for proportion breakdown."""
    v = _visual_base(x, y, w, h, "donutChart", f"donut_{measure.name}")
    v["config"] = {
        "singleVisual": {
            "visualType": "donutChart",
            "projections": {
                "Category": [{"queryRef": f"{dim_table.table_name}.{dim_col}"}],
                "Y":        [{"queryRef": f"{fact_table}.{measure.display_name}"}],
            },
            "prototypeQuery": {
                "Select": [
                    {
                        "Column": {
                            "Expression": {"SourceRef": {"Source": dim_table.table_name}},
                            "Property": dim_col,
                        },
                        "Name": f"{dim_table.table_name}.{dim_col}",
                    },
                    {
                        "Measure": {
                            "Expression": {"SourceRef": {"Source": fact_table}},
                            "Property": measure.display_name,
                        },
                        "Name": f"{fact_table}.{measure.display_name}",
                    },
                ],
                "From": [
                    {"Name": dim_table.table_name, "Entity": dim_table.table_name},
                    {"Name": fact_table,           "Entity": fact_table},
                ],
                "Top": {"Count": 8},
            },
            "objects": {
                "title": [{"properties": {
                    "show":      {"expr": {"Literal": {"Value": "true"}}},
                    "titleText": {"expr": {"Literal": {"Value": f"'{measure.display_name} Mix'"}}},
                    "fontSize":  {"expr": {"Literal": {"Value": "10D"}}},
                    "fontColor": {"solid": {"color": "#0F2D52"}},
                }}],
            },
        }
    }
    return v


def _matrix_visual(measures: list[MeasureDefinition],
                   row_table: FileMeta, row_col: str,
                   x: int, y: int, w: int, h: int,
                   fact_table: str) -> dict:
    """Matrix (pivot table) with up to 3 measures as columns."""
    use_measures = measures[:3]
    v = _visual_base(x, y, w, h, "pivotTable", f"matrix_summary")

    value_projections = [
        {"queryRef": f"{fact_table}.{m.display_name}"}
        for m in use_measures
    ]
    value_selects = [
        {
            "Measure": {
                "Expression": {"SourceRef": {"Source": fact_table}},
                "Property": m.display_name,
            },
            "Name": f"{fact_table}.{m.display_name}",
        }
        for m in use_measures
    ]

    v["config"] = {
        "singleVisual": {
            "visualType": "pivotTable",
            "projections": {
                "Rows":   [{"queryRef": f"{row_table.table_name}.{row_col}"}],
                "Values": value_projections,
            },
            "prototypeQuery": {
                "Select": [
                    {
                        "Column": {
                            "Expression": {"SourceRef": {"Source": row_table.table_name}},
                            "Property": row_col,
                        },
                        "Name": f"{row_table.table_name}.{row_col}",
                    },
                    *value_selects,
                ],
                "From": [
                    {"Name": row_table.table_name, "Entity": row_table.table_name},
                    {"Name": fact_table,           "Entity": fact_table},
                ],
                "OrderBy": [{
                    "Direction": 2,
                    "Expression": {
                        "Measure": {
                            "Expression": {"SourceRef": {"Source": fact_table}},
                            "Property": use_measures[0].display_name,
                        }
                    },
                }],
            },
            "objects": {
                "title": [{"properties": {
                    "show":      {"expr": {"Literal": {"Value": "true"}}},
                    "titleText": {"expr": {"Literal": {"Value": "'Summary Matrix'"}}},
                    "fontSize":  {"expr": {"Literal": {"Value": "10D"}}},
                    "fontColor": {"solid": {"color": "#0F2D52"}},
                }}],
                "columnHeaders": [{"properties": {
                    "fontBold":        {"expr": {"Literal": {"Value": "true"}}},
                    "backColor":       {"solid": {"color": "#0F2D52"}},
                    "fontColor":       {"solid": {"color": "#FFFFFF"}},
                    "fontSize":        {"expr": {"Literal": {"Value": "9D"}}},
                }}],
            },
        }
    }
    return v


def _slicer_visual(dim_table: FileMeta, dim_col: str,
                   x: int, y: int, w: int, h: int) -> dict:
    """Dropdown slicer for a dimension column."""
    v = _visual_base(x, y, w, h, "slicer", f"slicer_{dim_table.table_name}_{dim_col}")
    v["config"] = {
        "singleVisual": {
            "visualType": "slicer",
            "projections": {
                "Values": [{"queryRef": f"{dim_table.table_name}.{dim_col}"}]
            },
            "prototypeQuery": {
                "Select": [{
                    "Column": {
                        "Expression": {"SourceRef": {"Source": dim_table.table_name}},
                        "Property": dim_col,
                    },
                    "Name": f"{dim_table.table_name}.{dim_col}",
                }],
                "From": [{"Name": dim_table.table_name, "Entity": dim_table.table_name}],
            },
            "objects": {
                "data": [{"properties": {
                    "mode": {"expr": {"Literal": {"Value": "'Dropdown'"}}},
                }}],
                "header": [{"properties": {
                    "show":      {"expr": {"Literal": {"Value": "true"}}},
                    "fontColor": {"solid": {"color": "#0F2D52"}},
                    "fontBold":  {"expr": {"Literal": {"Value": "true"}}},
                    "fontSize":  {"expr": {"Literal": {"Value": "9D"}}},
                }}],
                "title": [{"properties": {
                    "show":      {"expr": {"Literal": {"Value": "true"}}},
                    "titleText": {"expr": {"Literal": {"Value": f"'Filter by {dim_col}'"}}},
                }}],
            },
        }
    }
    return v


# ── Visual selection logic ────────────────────────────────────────────────

def _pick_dimension_col(meta: FileMeta) -> Optional[str]:
    """
    Pick the best non-PK column from a dimension table for use as a
    categorical axis. Prefers low-to-medium cardinality text columns.
    """
    candidates = []
    for col in meta.columns:
        if col.is_pk_candidate:
            continue
        if col.is_numeric or col.is_date:
            continue
        candidates.append((col.unique_count, col.name))
    if not candidates:
        # fall back to first non-numeric column
        for col in meta.columns:
            if not col.is_numeric:
                return col.name
        return meta.columns[0].name if meta.columns else None
    # Sort by cardinality: prefer 2–50 unique values (ideal for charts)
    candidates.sort(key=lambda x: abs(x[0] - 15))
    return candidates[0][1]


def _find_date_info(model: SemanticModel) -> tuple[Optional[str], Optional[str]]:
    """Find a date column and its table from the model."""
    for meta in model.tables:
        for col in meta.columns:
            if col.is_date:
                return meta.table_name, col.name
    return None, None


def _layout_visuals_grid(visuals: list[dict],
                          start_x: int, start_y: int,
                          total_w: int, h: int, cols: int) -> None:
    """
    Re-layout a list of visuals into a grid in-place.
    Each visual gets equal width; rows wrap at `cols` columns.
    """
    if not visuals:
        return
    cell_w = (total_w - MARGIN * (cols - 1)) // cols
    for i, v in enumerate(visuals):
        col_i = i % cols
        row_i = i // cols
        v["x"] = start_x + col_i * (cell_w + MARGIN)
        v["y"] = start_y + row_i * (h + MARGIN)
        v["width"]  = cell_w
        v["height"] = h



def _stringify_report_fields(obj):
    """
    Recursively walk the report dict and convert any 'config', 'filters',
    'objects' values that are dicts or lists into JSON strings.
    Power BI Desktop May 2026+ (.pbir format) requires these as strings.
    """
    if isinstance(obj, dict):
        for key in list(obj.keys()):
            if key in ("config", "filters", "objects"):
                if isinstance(obj[key], (dict, list)):
                    obj[key] = json.dumps(obj[key], separators=(',', ':'))
            else:
                _stringify_report_fields(obj[key])
    elif isinstance(obj, list):
        for item in obj:
            _stringify_report_fields(item)


def export_report_json(model: SemanticModel) -> str:
    """
    Generate a Power BI report layout JSON file.

    Visual selection strategy:
    - KPI cards row   → one card per KPI measure (up to 5)
    - Time series     → line chart if date column found
    - Bar charts      → one per dimension table × top measure
    - Donut chart     → proportion breakdown for count/ratio measures
    - Matrix          → summary pivot if 2+ measures exist
    - Slicers         → one per dimension table (right column)

    Returns JSON string for report.json (use inside .pbip folder).
    """
    if not model.tables:
        return json.dumps({"error": "No tables in model"})

    fact_table = model.tables[0].table_name
    dim_tables = model.tables[1:] if len(model.tables) > 1 else []

    kpi_measures  = [m for m in model.measures if m.is_kpi]
    all_measures  = model.measures
    top_measure   = all_measures[0] if all_measures else None

    visuals: list[dict] = []

    # ── Title ─────────────────────────────────────────────────────────────
    visuals.append(_title_visual(model.project_name))

    # ── KPI Cards ────────────────────────────────────────────────────────
    kpi_candidates = kpi_measures if kpi_measures else all_measures[:5]
    if kpi_candidates:
        n    = min(len(kpi_candidates), 5)
        w    = (CANVAS_W - 2 * MARGIN - MARGIN * (n - 1)) // n
        for i, m in enumerate(kpi_candidates[:n]):
            x = MARGIN + i * (w + MARGIN)
            visuals.append(_kpi_card_visual(m, x, KPI_ROW_Y, w, KPI_H, fact_table))

    # ── Main visuals area ─────────────────────────────────────────────────
    # Reserve right column (1/4 width) for slicers
    SLICER_W  = 200
    CHART_W   = CANVAS_W - 2 * MARGIN - SLICER_W - MARGIN
    chart_visuals: list[dict] = []

    # Line chart for time dimension
    date_table_name, date_col = _find_date_info(model)
    if date_col and top_measure:
        dt = date_table_name or fact_table
        chart_visuals.append(
            _line_chart_visual(top_measure, date_col, dt,
                               0, 0,        # positioned later
                               CHART_W // VISUAL_COLS, VISUAL_H // 2,
                               fact_table)
        )

    # Bar + Donut charts per dimension table
    for dim_meta in dim_tables[:4]:
        dim_col = _pick_dimension_col(dim_meta)
        if dim_col is None or not top_measure:
            continue

        chart_visuals.append(
            _bar_chart_visual(top_measure, dim_meta, dim_col,
                              0, 0, 0, 0, fact_table)
        )

        # Donut for count/ratio/second measure
        if len(all_measures) > 1:
            m2 = all_measures[1]
            chart_visuals.append(
                _donut_chart_visual(m2, dim_meta, dim_col,
                                    0, 0, 0, 0, fact_table)
            )

    # Matrix
    if len(all_measures) >= 2 and dim_tables:
        best_dim = dim_tables[0]
        dim_col  = _pick_dimension_col(best_dim)
        if dim_col:
            chart_visuals.append(
                _matrix_visual(all_measures, best_dim, dim_col,
                               0, 0, 0, 0, fact_table)
            )

    # Layout chart visuals into grid
    _layout_visuals_grid(
        chart_visuals,
        start_x=MARGIN,
        start_y=VISUAL_ROW_Y,
        total_w=CHART_W,
        h=VISUAL_H // max(1, -(-len(chart_visuals) // VISUAL_COLS)),  # ceiling div
        cols=VISUAL_COLS,
    )
    visuals.extend(chart_visuals)

    # ── Slicers (right column) ────────────────────────────────────────────
    slicer_x  = CANVAS_W - MARGIN - SLICER_W
    slicer_h  = 100
    slicer_y  = VISUAL_ROW_Y
    for dim_meta in dim_tables[:4]:
        dim_col = _pick_dimension_col(dim_meta)
        if dim_col:
            visuals.append(
                _slicer_visual(dim_meta, dim_col,
                               slicer_x, slicer_y, SLICER_W, slicer_h)
            )
            slicer_y += slicer_h + MARGIN

    # ── Report JSON ──────────────────────────────────────────────────────
    report = {
        "id":          _new_guid(),
        "name":        model.project_name,
        "reportSchemaVersion": "1.13.0",
        "dataTransforms": {},
        "sections": [
            {
                "id":          _new_guid(),
                "name":        "Overview",
                "displayName": f"{model.project_name} — Overview",
                "filters":     [],
                "ordinal":     0,
                "visualContainers": visuals,
                "config": {
                    "type": "report",
                    "themeCollection": {
                        "baseTheme": {
                            "name": "CY24SU10",
                            "version": "5.63",
                            "type": "SharedResources",
                        }
                    },
                    "canvasLayout": {
                        "canvasSize": {
                            "width":  CANVAS_W,
                            "height": CANVAS_H,
                        },
                        "backgroundImage": {"transparency": 100},
                    },
                    "activeSectionIndex": 0,
                },
            }
        ],
        "config": {
            "version":     "1.13.0",
            "themeCollection": {
                "baseTheme": {
                    "name": "CY24SU10",
                    "version": "5.63",
                    "type": "SharedResources",
                }
            },
            "settings": {
                "useStylableVisualContainerHeader": True,
                "allowChangeFilterTypes": True,
                "useDefaultAggregateDisplayName": True,
            },
            "objects": {
                "section": [{
                    "properties": {
                        "background": {"solid": {"color": "#F4F4FA"}},
                        "wallpaper":  {"solid": {"color": "#E3F2FD"}},
                    }
                }]
            },
        },
        "annotations": [
            {"name": "GeneratedBy",  "value": "AI Reporting Automation System v1.0"},
            {"name": "ModelID",      "value": model.model_id},
            {"name": "ProjectID",    "value": model.project_id},
            {"name": "VisualCount",  "value": str(len(visuals))},
        ],
    }

    # Power BI May 2026+ requires config/filters/objects to be JSON strings not objects
    _stringify_report_fields(report)
    return json.dumps(report, indent=2, default=str)


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — README / IMPORT GUIDE
# ─────────────────────────────────────────────────────────────────────────────

def _build_readme(model: SemanticModel) -> str:
    built = str(model.built_at)[:19] if model.built_at else "unknown"
    measure_list = "\n".join(
        f"  • {m.display_name}  ({m.aggregation.value})"
        + ("  ← KPI" if m.is_kpi else "")
        for m in model.measures
    )
    rel_list = "\n".join(
        f"  • {r.from_table}.{r.from_column} → {r.to_table}.{r.to_column}"
        for r in model.relationships
    )
    table_list = "\n".join(
        f"  • {t.table_name}  ({t.row_count:,} rows, {t.col_count} columns)"
        for t in model.tables
    )

    return f"""
╔══════════════════════════════════════════════════════════════════╗
║         POWER BI EXPORT — IMPORT INSTRUCTIONS                    ║
║         Generated by AI Reporting Automation System v1.0         ║
╚══════════════════════════════════════════════════════════════════╝

Project:    {model.project_name}
Model ID:   {model.model_id}
Built:      {built}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 CONTENTS OF THIS ZIP
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  model.bim       — Tabular Model BIM (semantic layer: tables,
                    relationships, measures, DAX, KPIs)

  report.json     — Power BI report layout (visuals, KPI cards,
                    bar/line/donut charts, matrix, slicers)

  README_IMPORT.txt — This file

  {_safe_project_name(model.project_name)}.pbip
  {_safe_project_name(model.project_name)}.Report/
  {_safe_project_name(model.project_name)}.SemanticModel/
                  — A Power BI Project (PBIP) — opens directly in
                    Power BI Desktop without Tabular Editor (see Method D).
                    This is a PREVIEW feature on Microsoft's side.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 HOW TO IMPORT INTO POWER BI DESKTOP (Recommended)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

METHOD D — Open the .pbip directly (Easiest, but PREVIEW feature)
  1. In Power BI Desktop: File → Options and settings → Options →
     Preview features → check "Power BI Project (.pbip) save option"
     (also enable "Store reports using enhanced metadata format (PBIR)"
     if prompted). Restart Power BI Desktop.
  2. Double-click {_safe_project_name(model.project_name)}.pbip
  3. Power BI Desktop opens the report and model directly — no
     Tabular Editor step needed.
  4. If Power BI Desktop reports an error opening a specific file,
     that error message will name the file and the problem — this
     project structure was hand-built rather than saved by Power BI
     Desktop itself, so treat this method as experimental.

METHOD A — External Tools / Tabular Editor (Most reliable)
  1. Install Tabular Editor 3 (free trial) or Tabular Editor 2 (free)
     https://tabulareditor.com
  2. Open Power BI Desktop → create a blank report
  3. In Power BI Desktop toolbar → External Tools → Tabular Editor
  4. In Tabular Editor: File → Open → From File → select model.bim
  5. Review tables, measures, relationships
  6. File → Save to Power BI Desktop (Ctrl+S)
  7. Back in Power BI Desktop, you will see all tables and measures loaded

METHOD B — XMLA Endpoint (Power BI Premium / Fabric)
  1. In your Power BI workspace: Settings → Enable XMLA endpoint
  2. Copy the workspace XMLA connection string
  3. In SQL Server Management Studio or Azure Data Studio:
     Connect → Analysis Services → paste XMLA connection string
  4. Right-click database → Restore from file → select model.bim
  5. Then connect Power BI Desktop to the published dataset

METHOD C — Manual (Fallback)
  1. Open Power BI Desktop → Get Data → Blank Query
  2. For each table in this model, create a query pointing to your data source
  3. In the Model view, recreate the relationships listed below
  4. In the Report view, use the New Measure button and paste the DAX formulas
     from the Measures sheet in the accompanying Excel workbook


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 HOW TO IMPORT THE REPORT LAYOUT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  The report.json file is a Power BI report layout file compatible
  with the .pbip (Power BI Project) format.

  To use it:
  1. Create a folder named: {model.project_name.replace(' ', '_')}.Report
  2. Place report.json inside it
  3. Create a companion file definition.pbir with this content:
     {{
       "version": "1.0",
       "datasetReference": {{
         "byPath": {{ "path": "../{model.project_name.replace(' ', '_')}.Dataset" }}
       }}
     }}
  4. Open the .pbip project file in Power BI Desktop (June 2023+ version)

  Alternatively, after loading your dataset via Method A above,
  in Tabular Editor: View → Report Layout → paste the report.json content.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 MODEL SUMMARY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TABLES ({len(model.tables)}):
{table_list or "  (none)"}

RELATIONSHIPS ({len(model.relationships)}):
{rel_list or "  (none)"}

MEASURES ({len(model.measures)}):
{measure_list or "  (none)"}


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 NEXT STEPS AFTER IMPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1. Connect your data sources: In Power BI Desktop → Transform Data,
     replace the placeholder M queries with your actual data connections
     (CSV files, SQL Server, SharePoint, etc.)

  2. Validate measure totals: Cross-check each KPI measure total against
     your source system to confirm the DAX formulas are correct.

  3. Apply Row-Level Security: The model includes a placeholder "ReportViewer"
     role. Add DAX filters in Power BI Desktop → Manage Roles to restrict
     data access per user.

  4. Customise visuals: The report layout is a starting point. Resize,
     recolour, and add drill-through as needed.

  5. Publish to Power BI Service: File → Publish → select your workspace.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 SUPPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  This export was generated by AI Reporting Automation System v1.0.
  All DAX formulas were generated from your protocol document.
  If a measure produces unexpected results, check the DAX formula
  in the Excel export (Measures sheet) and adjust the base column
  or filter conditions as needed.

  Generated: {built}
  Model ID:  {model.model_id}
""".strip()


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3B — .PBIP PROJECT STRUCTURE (direct double-click open, no Tabular Editor)
# ─────────────────────────────────────────────────────────────────────────────

def _safe_project_name(name: str) -> str:
    """Sanitize a project name for use as a Windows-safe folder/file name."""
    name = (name or "PowerBI_Project").strip()
    for ch in '<>:"/\\|?*':
        name = name.replace(ch, "_")
    return name or "PowerBI_Project"


def build_pbip_files(model: SemanticModel, bim_str: str, report_str: str) -> dict:
    """
    Build the file map for a .pbip project folder structure, so the export
    can be opened directly in Power BI Desktop (double-click the .pbip)
    instead of requiring Tabular Editor as an intermediate step.

    Returns {relative_path_within_zip: text_content}.

    IMPORTANT — this requires Power BI Desktop preview features to be
    enabled first: File > Options and settings > Options > Preview features
    > check "Power BI Project (.pbip) save option". This whole feature is
    still in preview on Microsoft's side, so treat this as experimental:
    if Power BI Desktop reports an error opening it, the error message will
    say exactly which file it didn't like, and that's fixable.

    Confidence note: the root .pbip file and definition.pbir content below
    match Microsoft's official documentation and independently-verified
    real-world examples. definition.pbism's exact content is reconstructed
    from Microsoft's description of its purpose (it isn't fully documented
    with a literal example anywhere public at time of writing) — it's the
    one piece here that's an educated reconstruction rather than a
    confirmed-correct example.
    """
    name = _safe_project_name(model.project_name or "PowerBI_Project")
    report_folder = f"{name}.Report"
    model_folder = f"{name}.SemanticModel"

    pbip_root = {
        "version": "1.0",
        "artifacts": [
            {"report": {"path": report_folder}}
        ],
        "settings": {"enableAutoRecovery": True},
    }

    definition_pbir = {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/2.0.0/schema.json",
        "version": "4.0",
        "datasetReference": {
            "byPath": {"path": f"../{model_folder}"}
        },
    }

    definition_pbism = {
        "version": "4.0",
    }

    files = {
        f"{name}.pbip": json.dumps(pbip_root, indent=2),
        f"{report_folder}/definition.pbir": json.dumps(definition_pbir, indent=2),
        f"{report_folder}/report.json": report_str,
        f"{model_folder}/definition.pbism": json.dumps(definition_pbism, indent=2),
        f"{model_folder}/model.bim": bim_str,
    }
    return files


def export_powerbi_package(model: SemanticModel, dfs: Optional[dict] = None) -> bytes:
    """
    Build and return a ZIP containing:
      model.bim          — BIM semantic model
      report.json        — Report layout
      README_IMPORT.txt  — Step-by-step import guide

    dfs: optional {table_name: DataFrame} of the real uploaded data. When
    provided, model.bim embeds the actual rows so the model works
    immediately on import. When omitted, tables come through schema-only.

    Returns bytes ready to write to disk or serve via HTTP.
    """
    bim_str    = export_bim(model, dfs)
    report_str = export_report_json(model)
    readme_str = _build_readme(model)
    pbip_files = build_pbip_files(model, bim_str, report_str)

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("model.bim",          bim_str)
        zf.writestr("report.json",        report_str)
        zf.writestr("README_IMPORT.txt",  readme_str)
        for rel_path, content in pbip_files.items():
            zf.writestr(rel_path, content)

    logger.info(
        "Power BI package built: %d tables, %d relationships, %d measures, %d visuals",
        len(model.tables), len(model.relationships), len(model.measures),
        len(json.loads(report_str).get("sections", [{}])[0].get("visualContainers", [])),
    )
    return buf.getvalue()