"""
core/report_generator.py
Generates the PDF Project Automation Completion Report.
Pulls all live data from ProjectContext — nothing is hardcoded.
"""
import io
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak, KeepTogether
)
from reportlab.platypus.flowables import Flowable
from reportlab.lib.colors import HexColor

from .models import (
    ProjectContext, MappingMethod, ResolutionMethod, ErrorSeverity
)

# ── Palette ────────────────────────────────────────────────────────────────
NAVY   = HexColor('#0F2D52')
BLUE   = HexColor('#1565C0')
BLUE_L = HexColor('#E3F2FD')
BLUE_P = HexColor('#F0F7FF')
TEAL   = HexColor('#00695C')
TEAL_L = HexColor('#E0F2F1')
AMB    = HexColor('#E65100')
AMB_L  = HexColor('#FFF3E0')
GRN    = HexColor('#1B5E20')
GRN_M  = HexColor('#2E7D32')
GRN_L  = HexColor('#E8F5E9')
RED    = HexColor('#B71C1C')
RED_L  = HexColor('#FFEBEE')
G900   = HexColor('#212121')
G700   = HexColor('#616161')
G400   = HexColor('#BDBDBD')
G200   = HexColor('#EEEEEE')
G100   = HexColor('#F5F5F5')
WHT    = HexColor('#FFFFFF')

PAGE_W, PAGE_H = letter
MARGIN = 0.65 * inch
CW = PAGE_W - 2 * MARGIN    # content width


# ── Helpers ────────────────────────────────────────────────────────────────

def S(name, **kw):
    return ParagraphStyle(name, **kw)

STYLES = {
    'body':       S('bd', fontName='Helvetica', fontSize=10, textColor=G900,
                    leading=16, spaceAfter=6, alignment=TA_JUSTIFY),
    'body_sm':    S('bs', fontName='Helvetica', fontSize=9, textColor=G700,
                    leading=14, spaceAfter=4),
    'sec_num':    S('sn', fontName='Helvetica-Bold', fontSize=9, textColor=BLUE,
                    leading=14, spaceAfter=2, spaceBefore=20),
    'sec_title':  S('st', fontName='Helvetica-Bold', fontSize=16, textColor=NAVY,
                    leading=22, spaceAfter=6),
    'sub':        S('su', fontName='Helvetica-Bold', fontSize=11, textColor=NAVY,
                    leading=16, spaceAfter=4, spaceBefore=10),
    'tbl_hdr':    S('th', fontName='Helvetica-Bold', fontSize=8.5, textColor=WHT,
                    leading=12, alignment=TA_CENTER),
    'tbl_hdr_l':  S('thl', fontName='Helvetica-Bold', fontSize=8.5, textColor=WHT,
                    leading=12),
    'tbl_c':      S('tc', fontName='Helvetica', fontSize=8.5, textColor=G900, leading=12),
    'tbl_cb':     S('tcb', fontName='Helvetica-Bold', fontSize=8.5, textColor=G900, leading=12),
    'tbl_cg':     S('tcg', fontName='Helvetica-Bold', fontSize=8.5, textColor=GRN_M, leading=12),
    'tbl_cr':     S('tcr', fontName='Helvetica-Bold', fontSize=8.5, textColor=RED, leading=12),
    'tbl_ca':     S('tca', fontName='Helvetica', fontSize=8.5, textColor=AMB, leading=12),
    'tbl_sm':     S('tcs', fontName='Helvetica', fontSize=7.5, textColor=G700, leading=11),
    'mono':       S('mn', fontName='Courier', fontSize=8, textColor=HexColor('#1A237E'), leading=12),
    'kpi_n':      S('kn', fontName='Helvetica-Bold', fontSize=22, textColor=NAVY,
                    leading=26, alignment=TA_CENTER),
    'kpi_l':      S('kl', fontName='Helvetica', fontSize=8, textColor=G700,
                    leading=12, alignment=TA_CENTER),
    'kpi_s':      S('ks', fontName='Helvetica-Bold', fontSize=8, textColor=GRN_M,
                    leading=12, alignment=TA_CENTER),
    'foot':       S('ft', fontName='Helvetica-Oblique', fontSize=8, textColor=G700,
                    leading=12, alignment=TA_CENTER),
}

_B = lambda c='CCCCCC', s=4: {'style': 'GRID', 'color': HexColor(c), 'thickness': s/4}

def sp(n=1): return Spacer(1, n * 6)
def hr(): return HRFlowable(width='100%', thickness=0.5, color=G400,
                             spaceAfter=5, spaceBefore=5)
def p(text, s='body'): return Paragraph(text, STYLES[s])
def bul(text): return Paragraph(f'\u2022 {text}', STYLES['body_sm'])


def sec(num, title):
    return KeepTogether([
        sp(2),
        Paragraph(f'SECTION {num}', STYLES['sec_num']),
        Paragraph(title, STYLES['sec_title']),
        HRFlowable(width='100%', thickness=1, color=BLUE,
                   spaceAfter=6, spaceBefore=2),
        sp(1),
    ])


def callout(label, body, bar=BLUE, bg=BLUE_L):
    return KeepTogether([
        sp(1),
        Table([[
            Paragraph(f'<b>{label}</b>',
                      ParagraphStyle('cl', fontName='Helvetica-Bold',
                                     fontSize=9.5, textColor=bar, leading=14)),
            Paragraph(body,
                      ParagraphStyle('cb', fontName='Helvetica',
                                     fontSize=9, textColor=G900, leading=14)),
        ]], colWidths=[1.3*inch, CW - 1.3*inch],
            style=TableStyle([
                ('BACKGROUND', (0,0), (-1,-1), bg),
                ('BOX',        (0,0), (-1,-1), 0.5, bar),
                ('LINEAFTER',  (0,0), (0,-1),  1,   bar),
                ('LEFTPADDING',  (0,0), (0,-1), 10),
                ('LEFTPADDING',  (1,0), (1,-1), 8),
                ('TOPPADDING',   (0,0), (-1,-1), 8),
                ('BOTTOMPADDING',(0,0), (-1,-1), 8),
                ('RIGHTPADDING', (0,0), (-1,-1), 8),
                ('VALIGN',       (0,0), (-1,-1), 'TOP'),
            ])),
        sp(1),
    ])


def base_ts():
    return [
        ('BACKGROUND', (0,0), (-1,0), NAVY),
        ('TEXTCOLOR',  (0,0), (-1,0), WHT),
        ('FONTNAME',   (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE',   (0,0), (-1,0), 8.5),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [WHT, G100]),
        ('FONTNAME',   (0,1), (-1,-1), 'Helvetica'),
        ('FONTSIZE',   (0,1), (-1,-1), 8.5),
        ('GRID',       (0,0), (-1,-1), 0.4, G400),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LEFTPADDING', (0,0), (-1,-1), 7),
        ('RIGHTPADDING', (0,0), (-1,-1), 7),
        ('VALIGN',     (0,0), (-1,-1), 'MIDDLE'),
    ]


def hcell(t, w, span=1):
    return Table([[Paragraph(t, STYLES['tbl_hdr'])]],
                 colWidths=[w],
                 style=TableStyle([
                     ('BACKGROUND', (0,0), (-1,-1), NAVY),
                     ('TOPPADDING', (0,0), (-1,-1), 6),
                     ('BOTTOMPADDING', (0,0), (-1,-1), 6),
                 ]))


def kpi_tile(num, label, sub='', bg=BLUE_P, nc=NAVY):
    w = (CW / 4) - 5
    rows = [[Paragraph(num, ParagraphStyle(
        'kn2', fontName='Helvetica-Bold', fontSize=20,
        textColor=nc, leading=24, alignment=TA_CENTER))]]
    rows.append([Paragraph(label, STYLES['kpi_l'])])
    if sub:
        rows.append([Paragraph(sub, STYLES['kpi_s'])])
    t = Table(rows, colWidths=[w])
    t.setStyle(TableStyle([
        ('BACKGROUND',    (0,0), (-1,-1), bg),
        ('BOX',           (0,0), (-1,-1), 0.5, G400),
        ('ALIGN',         (0,0), (-1,-1), 'CENTER'),
        ('TOPPADDING',    (0,0), (-1,-1), 10),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10),
        ('ROWBACKGROUNDS',(0,0), (-1,-1), [bg]),
    ]))
    return t


# ── Page callbacks ─────────────────────────────────────────────────────────

def make_callbacks(project_name: str, generated: str):
    def first_page(c, doc):
        c.saveState()
        # Navy top band
        c.setFillColor(NAVY)
        c.rect(0, PAGE_H * 0.40, PAGE_W, PAGE_H * 0.60, fill=1, stroke=0)
        # Blue accent stripe
        c.setFillColor(BLUE)
        c.rect(0, PAGE_H * 0.40, PAGE_W, 5, fill=1, stroke=0)
        # Left accent bar
        c.setFillColor(HexColor('#1E88E5'))
        c.rect(MARGIN, PAGE_H * 0.53, 4, PAGE_H * 0.34, fill=1, stroke=0)
        # Tag pill
        c.setFillColor(HexColor('#1E88E5'))
        c.roundRect(MARGIN + 14, PAGE_H * 0.84, 210, 22, 4, fill=1, stroke=0)
        c.setFillColor(WHT)
        c.setFont('Helvetica-Bold', 8)
        c.drawString(MARGIN + 22, PAGE_H * 0.84 + 7, 'AUTOMATION COMPLETION REPORT')
        # Title
        c.setFillColor(WHT)
        c.setFont('Helvetica-Bold', 30)
        title_lines = _wrap_title(project_name, 38)
        y = PAGE_H * 0.68
        for line in title_lines[:3]:
            c.drawString(MARGIN + 14, y, line)
            y -= 36
        # Subtitle
        c.setFillColor(HexColor('#90CAF9'))
        c.setFont('Helvetica', 11)
        c.drawString(MARGIN + 14, y - 4, 'Semantic Model Build \u2014 Phase 1 Complete')
        # Light lower section
        c.setFillColor(G100)
        c.rect(0, 0, PAGE_W, PAGE_H * 0.40, fill=1, stroke=0)
        c.setFillColor(BLUE)
        c.rect(0, PAGE_H * 0.40, PAGE_W, 5, fill=1, stroke=0)
        # Generated note at bottom
        c.setFillColor(G700)
        c.setFont('Helvetica', 7.5)
        c.drawString(MARGIN, 22,
            f'Generated by AI Reporting Automation System v1.0  \u2022  '
            f'{generated}  \u2022  CONFIDENTIAL')
        c.restoreState()

    def later_pages(c, doc):
        c.saveState()
        c.setFillColor(NAVY)
        c.rect(0, PAGE_H - 34, PAGE_W, 34, fill=1, stroke=0)
        c.setFillColor(WHT)
        c.setFont('Helvetica-Bold', 8)
        c.drawString(MARGIN, PAGE_H - 20, project_name.upper())
        c.setFont('Helvetica', 8)
        c.drawRightString(PAGE_W - MARGIN, PAGE_H - 20,
                          'AUTOMATION COMPLETION REPORT  \u2022  CONFIDENTIAL')
        c.setFillColor(G400)
        c.rect(MARGIN, 30, CW, 0.5, fill=1, stroke=0)
        c.setFillColor(G700)
        c.setFont('Helvetica', 7.5)
        c.drawString(MARGIN, 18,
            f'Generated {generated}  \u2022  AI Reporting Automation System v1.0')
        c.drawRightString(PAGE_W - MARGIN, 18, f'Page {doc.page}')
        c.restoreState()

    return first_page, later_pages


def _wrap_title(text: str, max_chars: int) -> list[str]:
    words = text.split()
    lines, current = [], []
    for w in words:
        if sum(len(x) + 1 for x in current) + len(w) > max_chars and current:
            lines.append(' '.join(current))
            current = [w]
        else:
            current.append(w)
    if current:
        lines.append(' '.join(current))
    return lines


# ── Cover meta table ───────────────────────────────────────────────────────

def cover_meta_table(ctx: ProjectContext) -> Table:
    rows = [
        ['Project ID',   ctx.project_id[:12] + '…'],
        ['Initiated',    str(ctx.created_at)[:10]],
        ['Completed',    str(ctx.last_updated)[:10]],
        ['Status',       'COMPLETED'],
    ]
    data = [[Paragraph(r[0], STYLES['tbl_hdr_l']),
             Paragraph(r[1], STYLES['tbl_c'])]
            for r in rows]
    t = Table(data, colWidths=[1.6*inch, 2.4*inch])
    ts = [
        ('ROWBACKGROUNDS', (0,0), (-1,-1), [G100, WHT]),
        ('GRID',           (0,0), (-1,-1), 0.4, G400),
        ('TOPPADDING',     (0,0), (-1,-1), 5),
        ('BOTTOMPADDING',  (0,0), (-1,-1), 5),
        ('LEFTPADDING',    (0,0), (-1,-1), 8),
        ('RIGHTPADDING',   (0,0), (-1,-1), 8),
        ('FONTNAME',       (0,0), (0,-1),  'Helvetica-Bold'),
        ('TEXTCOLOR',      (0,3), (0,3),   WHT),
        ('BACKGROUND',     (0,3), (-1,3),  GRN_M),
        ('FONTNAME',       (0,3), (-1,3),  'Helvetica-Bold'),
    ]
    t.setStyle(TableStyle(ts))
    return t


# ── Main generator ─────────────────────────────────────────────────────────

def generate_completion_report(ctx: ProjectContext) -> bytes:
    """
    Build the full PDF completion report from a ProjectContext.
    Returns bytes ready to write to disk or serve via HTTP.
    """
    generated = datetime.now().strftime('%d %B %Y, %H:%M')
    model = ctx.semantic_model

    first_page, later_pages = make_callbacks(ctx.project_name, generated)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=letter,
        leftMargin=MARGIN, rightMargin=MARGIN,
        topMargin=MARGIN + 0.44*inch, bottomMargin=MARGIN,
        title=f'Completion Report — {ctx.project_name}',
        author='AI Reporting Automation System',
    )

    story = [PageBreak()]   # cover is drawn by first_page callback

    # ── Section 1: Executive Summary ──────────────────────────────────────
    story.append(sec('01', 'Executive Summary'))

    total_rows = sum(f.row_count for f in ctx.raw_files)
    total_files = len(ctx.raw_files) + len(ctx.mapping_files)
    resolved = [e for e in ctx.errors
                if e.resolution_method != ResolutionMethod.PENDING]
    user_decisions = [e for e in resolved
                      if e.resolution_method == ResolutionMethod.USER_DECISION]
    auto_resolved  = [e for e in resolved
                      if e.resolution_method == ResolutionMethod.AUTO]

    story.append(p(
        f'This report documents the successful completion of Phase 1 of the AI-powered '
        f'reporting automation pipeline for <b>{ctx.project_name}</b>. '
        f'The semantic model has been fully constructed, validated, and is ready for export.'
    ))
    story.append(sp())

    # KPI row
    kpis = [
        kpi_tile(f'{total_rows:,}', 'Rows processed',
                 f'{len(ctx.raw_files)} raw file(s)', BLUE_P, NAVY),
        kpi_tile(str(len(ctx.measures)), 'Measures built',
                 'from protocol document', BLUE_P, NAVY),
        kpi_tile(str(len(ctx.mapping_decisions)), 'Column mappings',
                 f'{total_files} files joined', BLUE_P, NAVY),
        kpi_tile(str(len(resolved)),
                 'Issues resolved',
                 f'{len(user_decisions)} user \u00b7 {len(auto_resolved)} auto',
                 GRN_L, GRN_M),
    ]
    kpi_row = Table([kpis],
                    colWidths=[(CW/4) - 4]*4,
                    spaceBefore=4, spaceAfter=4)
    kpi_row.setStyle(TableStyle([
        ('ALIGN',  (0,0), (-1,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING',  (0,0), (-1,-1), 3),
        ('RIGHTPADDING', (0,0), (-1,-1), 3),
    ]))
    story.append(kpi_row)
    story.append(sp(2))

    status_text = (
        'Model is production-ready. '
        + (f'All {len(ctx.measures)} measures have been generated and DAX-validated. ' if ctx.measures else '')
        + f'{len(resolved)} data quality decisions were logged with full audit trail.'
    )
    story.append(callout('Status', status_text, GRN_M, GRN_L))

    # ── Section 2: Input Files ─────────────────────────────────────────────
    story.append(sec('02', 'Input Files'))

    if ctx.raw_files:
        story.append(p('Raw data files', 'sub'))
        rf_data = [['File', 'Rows', 'Columns', 'Size (MB)', 'PK candidates']]
        for f in ctx.raw_files:
            rf_data.append([
                Paragraph(f.file_name, STYLES['tbl_cb']),
                Paragraph(f'{f.row_count:,}', STYLES['tbl_c']),
                Paragraph(str(f.col_count), STYLES['tbl_c']),
                Paragraph(str(f.file_size_mb), STYLES['tbl_c']),
                Paragraph(', '.join(f.pk_candidates[:3]) or '—', STYLES['tbl_sm']),
            ])
        t = Table(rf_data, colWidths=[2.4*inch, 0.9*inch, 0.8*inch, 0.85*inch, 1.7*inch])
        t.setStyle(TableStyle(base_ts()))
        story.append(t)
        story.append(sp(2))

    if ctx.mapping_files:
        story.append(p('Mapping and dimension files', 'sub'))
        mf_data = [['File', 'Rows', 'Columns', 'Size (MB)', 'PK candidates']]
        for f in ctx.mapping_files:
            mf_data.append([
                Paragraph(f.file_name, STYLES['tbl_cb']),
                Paragraph(f'{f.row_count:,}', STYLES['tbl_c']),
                Paragraph(str(f.col_count), STYLES['tbl_c']),
                Paragraph(str(f.file_size_mb), STYLES['tbl_c']),
                Paragraph(', '.join(f.pk_candidates[:3]) or '—', STYLES['tbl_sm']),
            ])
        t = Table(mf_data, colWidths=[2.4*inch, 0.9*inch, 0.8*inch, 0.85*inch, 1.7*inch])
        t.setStyle(TableStyle(base_ts()))
        story.append(t)
        story.append(sp(2))

    if ctx.protocol_file_name:
        story.append(p('Protocol document', 'sub'))
        proto_data = [
            ['Filename', 'Measures extracted', 'Clarifications required'],
            [
                Paragraph(ctx.protocol_file_name, STYLES['tbl_cb']),
                Paragraph(str(len(ctx.measures)), STYLES['tbl_cg']),
                Paragraph(
                    str(sum(1 for m in ctx.measures if m.clarification_answers)),
                    STYLES['tbl_c']
                ),
            ]
        ]
        t = Table(proto_data, colWidths=[3*inch, 1.8*inch, 1.8*inch])
        t.setStyle(TableStyle(base_ts()))
        story.append(t)

    # ── Section 3: Automapping Results ─────────────────────────────────────
    if ctx.mapping_decisions:
        story.append(sec('03', 'Automapping Results'))

        exact  = [d for d in ctx.mapping_decisions if d.method == MappingMethod.EXACT]
        fuzzy  = [d for d in ctx.mapping_decisions if d.method == MappingMethod.FUZZY]
        ai_inf = [d for d in ctx.mapping_decisions if d.method == MappingMethod.AI_INFERRED]
        user_d = [d for d in ctx.mapping_decisions if d.method == MappingMethod.USER_DEFINED]
        unmap  = [d for d in ctx.mapping_decisions if d.method == MappingMethod.UNMAPPED]

        story.append(p(
            f'The automapping engine ran a three-pass analysis across all uploaded files. '
            f'{len(exact)} columns matched exactly, {len(fuzzy)} by fuzzy matching, '
            f'{len(ai_inf)} by AI semantic inference'
            + (f', and {len(user_d)} were manually assigned by the user' if user_d else '')
            + f'. {len(unmap)} column(s) remained unmapped.'
        ))
        story.append(sp())

        map_data = [['Source', 'Maps to', 'Conf.', 'Method', 'Status']]
        for d in ctx.mapping_decisions:
            conf_style = (STYLES['tbl_cg'] if d.confidence >= 0.9
                          else STYLES['tbl_ca'] if d.confidence >= 0.7
                          else STYLES['tbl_cr'])
            stat_style = (STYLES['tbl_cg'] if d.user_confirmed
                          else STYLES['tbl_ca'])
            map_data.append([
                Paragraph(f'{d.source_table}.{d.source_column}', STYLES['mono']),
                Paragraph(
                    f'{d.target_table}.{d.target_column}'
                    if d.target_table else '—',
                    STYLES['mono']
                ),
                Paragraph(
                    f'{d.confidence:.0%}' if d.confidence else '—',
                    conf_style
                ),
                Paragraph(d.method.value, STYLES['tbl_c']),
                Paragraph(
                    'Confirmed' if d.user_confirmed else 'Pending',
                    stat_style
                ),
            ])
        t = Table(map_data,
                  colWidths=[2.0*inch, 2.0*inch, 0.6*inch, 1.1*inch, 0.9*inch])
        t.setStyle(TableStyle(base_ts()))
        story.append(t)

    # ── Section 4: Generated Measures ─────────────────────────────────────
    if ctx.measures:
        story.append(sec('04', 'Generated Measures'))
        story.append(p(
            f'{len(ctx.measures)} measures were extracted from the protocol document '
            f'and converted to DAX formulas. '
            + ('All formulas have been validated for syntactic correctness.'
               if ctx.measures else '')
        ))
        story.append(sp())

        meas_data = [['Measure', 'Aggregation', 'Format', 'KPI', 'Conf.', 'DAX (summary)']]
        for m in ctx.measures:
            conf_style = (STYLES['tbl_cg'] if m.confidence >= 0.9
                          else STYLES['tbl_ca'])
            dax_short = (m.dax_formula or '')[:60] + ('…' if m.dax_formula and len(m.dax_formula) > 60 else '')
            meas_data.append([
                Paragraph(m.display_name or m.name, STYLES['tbl_cb']),
                Paragraph(m.aggregation.value, STYLES['tbl_c']),
                Paragraph(m.format_string, STYLES['mono']),
                Paragraph('✓' if m.is_kpi else '—',
                           STYLES['tbl_cg'] if m.is_kpi else STYLES['tbl_c']),
                Paragraph(f'{m.confidence:.0%}', conf_style),
                Paragraph(dax_short, STYLES['tbl_sm']),
            ])
        t = Table(meas_data,
                  colWidths=[1.4*inch, 0.85*inch, 0.8*inch, 0.4*inch, 0.5*inch, 2.7*inch])
        t.setStyle(TableStyle(base_ts()))
        story.append(t)

    # ── Section 5: Data Quality & Error Resolution ─────────────────────────
    story.append(sec('05', 'Data Quality and Error Resolution'))

    if not ctx.errors:
        story.append(p('No data quality issues were detected during processing.'))
    else:
        story.append(p(
            f'{len(ctx.errors)} issue(s) were detected during file processing and mapping. '
            f'{len(user_decisions)} required user decisions; {len(auto_resolved)} were '
            f'auto-resolved. All decisions are documented below and in the accompanying '
            f'audit log JSON.'
        ))
        story.append(sp())

        err_data = [['ID', 'Category', 'Severity', 'Table/Column',
                     'Resolution', 'Action', 'Status']]
        for e in ctx.errors:
            sev_style = (STYLES['tbl_cr'] if e.severity in
                         (ErrorSeverity.HIGH, ErrorSeverity.CRITICAL, ErrorSeverity.BLOCKER)
                         else STYLES['tbl_ca'] if e.severity == ErrorSeverity.MEDIUM
                         else STYLES['tbl_c'])
            stat_style = (STYLES['tbl_cg']
                          if e.resolution_method != ResolutionMethod.PENDING
                          else STYLES['tbl_ca'])
            chosen = next(
                (o.label for o in e.options if o.option_id == e.chosen_option_id), ''
            ) if e.chosen_option_id else ('(auto)' if e.resolution_method == ResolutionMethod.AUTO else '—')

            err_data.append([
                Paragraph(e.error_id[:6], STYLES['tbl_sm']),
                Paragraph(e.category.value.replace('_', ' ').title(), STYLES['tbl_c']),
                Paragraph(e.severity.value, sev_style),
                Paragraph(f'{e.affected_table}\n{e.affected_column}', STYLES['tbl_sm']),
                Paragraph(e.resolution_method.value.replace('_', ' ').title(), STYLES['tbl_c']),
                Paragraph(chosen[:50], STYLES['tbl_sm']),
                Paragraph(
                    'Resolved' if e.resolution_method != ResolutionMethod.PENDING else 'Pending',
                    stat_style
                ),
            ])
        t = Table(err_data,
                  colWidths=[0.5*inch, 1.0*inch, 0.65*inch, 1.2*inch,
                              0.9*inch, 1.35*inch, 0.65*inch])
        t.setStyle(TableStyle(base_ts()))
        story.append(t)

        # Narrative for user decisions
        if user_decisions:
            story.append(sp(2))
            story.append(p('User decision dialogue summaries', 'sub'))
            for e in user_decisions:
                chosen_opt = next(
                    (o for o in e.options if o.option_id == e.chosen_option_id), None
                )
                chosen_label = chosen_opt.label if chosen_opt else e.chosen_option_id
                story.append(p(
                    f'<b>{e.sub_type.replace("_", " ").title()} — '
                    f'{e.affected_table}.{e.affected_column}:</b> '
                    f'{e.detail[:200]}{"…" if len(e.detail) > 200 else ""} '
                    f'<b>User decision:</b> {chosen_label}. '
                    + (e.resolution_notes if e.resolution_notes else ''),
                    'body_sm'
                ))
                story.append(sp())

        story.append(callout(
            'Audit trail',
            'A complete machine-readable resolution log (error_resolution_log.json) '
            'is included with the deliverables. It records every error, all options '
            'presented, the user\'s choice, rows affected, and timestamps \u2014 '
            'suitable for GDPR lineage documentation and SOX audit requirements.',
            AMB, AMB_L
        ))

    # ── Section 6: Semantic Model ──────────────────────────────────────────
    if model:
        story.append(sec('06', 'Semantic Model Summary'))

        model_rows = [
            ('Tables in model',      str(len(model.tables))),
            ('Relationships',        str(len(model.relationships))),
            ('Measures',             str(len(model.measures))),
            ('Total rows',           f'{model.total_rows:,}'),
            ('Build warnings',       str(len(model.build_warnings)) or 'None'),
            ('Built at',             str(model.built_at)[:19] if model.built_at else '—'),
        ]
        md_data = [['Component', 'Value']] + [
            [Paragraph(r[0], STYLES['tbl_cb']), Paragraph(r[1], STYLES['tbl_c'])]
            for r in model_rows
        ]
        t = Table(md_data, colWidths=[2.5*inch, CW - 2.5*inch])
        t.setStyle(TableStyle(base_ts()))
        story.append(t)

        if model.relationships:
            story.append(sp(2))
            story.append(p('Relationship graph', 'sub'))
            rel_data = [['From', 'Column', 'To', 'Column', 'Type', 'Active']]
            for rel in model.relationships:
                rel_data.append([
                    Paragraph(rel.from_table, STYLES['mono']),
                    Paragraph(rel.from_column, STYLES['mono']),
                    Paragraph(rel.to_table, STYLES['mono']),
                    Paragraph(rel.to_column, STYLES['mono']),
                    Paragraph(rel.join_type.value, STYLES['tbl_c']),
                    Paragraph('Yes' if rel.is_active else 'No',
                               STYLES['tbl_cg'] if rel.is_active else STYLES['tbl_c']),
                ])
            t = Table(rel_data,
                      colWidths=[1.4*inch, 1.4*inch, 1.4*inch, 1.4*inch, 1.0*inch, 0.55*inch])
            t.setStyle(TableStyle(base_ts()))
            story.append(t)

    # ── Section 7: Sign-off ────────────────────────────────────────────────
    story.append(sec('07', 'Sign-off and Acknowledgement'))

    story.append(p(
        f'This report is the formal completion record for Phase 1 of the '
        f'<b>{ctx.project_name}</b> automation project. '
        f'It documents all inputs received, processing decisions made, '
        f'data quality resolutions agreed, and outputs generated.'
    ))
    story.append(sp())

    signoff = [
        ['Field', 'Value'],
        ['Project name',    ctx.project_name],
        ['Project ID',      ctx.project_id],
        ['Pipeline version','AI Reporting Automation System v1.0'],
        ['Phase completed', 'Phase 1 \u2014 Semantic Model Build'],
        ['Session started', str(ctx.created_at)[:19]],
        ['Report generated', generated],
        ['User decisions',  str(len(user_decisions))],
        ['Auto-resolutions', str(len(auto_resolved))],
        ['Pending issues',  str(len(ctx.pending_errors()))],
        ['Phase 2 status',  'Available on request'],
    ]
    so_data = [
        [Paragraph(r[0], STYLES['tbl_hdr_l']),
         Paragraph(r[1], STYLES['tbl_hdr_l'])]
        if i == 0 else
        [Paragraph(r[0], STYLES['tbl_cb']),
         Paragraph(r[1], STYLES['tbl_c'])]
        for i, r in enumerate(signoff)
    ]
    t = Table(so_data, colWidths=[2.0*inch, CW - 2.0*inch])
    so_ts = base_ts()
    so_ts += [
        ('FONTNAME', (0,1), (-1,-1), 'Helvetica'),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [WHT, G100]),
    ]
    t.setStyle(TableStyle(so_ts))
    story.append(t)

    story.append(sp(3))
    story.append(HRFlowable(width='100%', thickness=0.5, color=G400,
                             spaceAfter=6, spaceBefore=6))
    story.append(sp())
    story.append(p(
        f'This report was automatically generated by the AI Reporting Automation System v1.0 '
        f'upon completion of the semantic model build pipeline. '
        f'All data quality decisions were made interactively through the chat interface '
        f'by an authorised user and are recorded in the accompanying audit log.',
        'foot'
    ))
    story.append(p(
        f'Report ID: {ctx.project_id[:8].upper()}-CR1  \u2022  '
        f'{generated}  \u2022  CONFIDENTIAL',
        'foot'
    ))

    # Build
    doc.build(story, onFirstPage=first_page, onLaterPages=later_pages)
    return buf.getvalue()
