from dataclasses import dataclass, asdict
from typing import List, Optional


@dataclass
class VisualDefinition:
    page: str
    visual_type: str
    title: str
    measure: str
    dimension: Optional[str] = None


def detect_dimensions(model):

    date_cols = []
    category_cols = []
    geo_cols = []

    for table in model.tables:

        if not hasattr(table, "columns"):
            continue

        for col in table.columns:

            name = col.name.lower()

            if any(x in name for x in [
                "date",
                "month",
                "year"
            ]):
                date_cols.append(col.name)

            elif any(x in name for x in [
                "region",
                "country",
                "state",
                "city",
                "location"
            ]):
                geo_cols.append(col.name)

            else:
                category_cols.append(col.name)

    return date_cols, category_cols, geo_cols


def generate_visuals(model) -> List[VisualDefinition]:

    visuals = []

    date_cols, category_cols, geo_cols = detect_dimensions(model)

    # KPI Cards
    for measure in model.measures:

        display_name = getattr(
            measure,
            "display_name",
            measure.name
        )

        visuals.append(
            VisualDefinition(
                page="Executive Summary",
                visual_type="card",
                title=display_name,
                measure=display_name
            )
        )

    # Trend Charts
    if date_cols:

        date_dim = date_cols[0]

        for measure in model.measures:

            display_name = getattr(
                measure,
                "display_name",
                measure.name
            )

            visuals.append(
                VisualDefinition(
                    page="Trend Analysis",
                    visual_type="line_chart",
                    title=f"{display_name} Trend",
                    measure=display_name,
                    dimension=date_dim
                )
            )

    # Category Charts
    if category_cols:

        category_dim = category_cols[0]

        for measure in model.measures:

            display_name = getattr(
                measure,
                "display_name",
                measure.name
            )

            visuals.append(
                VisualDefinition(
                    page="Category Analysis",
                    visual_type="bar_chart",
                    title=f"{display_name} by {category_dim}",
                    measure=display_name,
                    dimension=category_dim
                )
            )

    # Geo Charts
    if geo_cols:

        geo_dim = geo_cols[0]

        for measure in model.measures:

            display_name = getattr(
                measure,
                "display_name",
                measure.name
            )

            visuals.append(
                VisualDefinition(
                    page="Regional Analysis",
                    visual_type="map",
                    title=f"{display_name} by {geo_dim}",
                    measure=display_name,
                    dimension=geo_dim
                )
            )

    return visuals


def visuals_to_json(visuals):

    pages = {}

    for visual in visuals:

        if visual.page not in pages:
            pages[visual.page] = []

        pages[visual.page].append(
            asdict(visual)
        )

    return pages