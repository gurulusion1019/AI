import streamlit as st
import requests
import json

API_BASE = "http://localhost:5000/api"

st.set_page_config(
    page_title="AI BI Copilot",
    layout="wide"
)

# -------------------------------
# SESSION STATE
# -------------------------------

if "session_id" not in st.session_state:
    st.session_state.session_id = None

if "messages" not in st.session_state:
    st.session_state.messages = []

if "workflow_state" not in st.session_state:
    st.session_state.workflow_state = "NOT_STARTED"

if "uploaded_files" not in st.session_state:
    st.session_state.uploaded_files = set()


# -------------------------------
# SIDEBAR
# -------------------------------

st.sidebar.title("AI BI Copilot")

st.sidebar.markdown("---")

st.sidebar.write("### Session")
st.sidebar.write(st.session_state.session_id)

st.sidebar.write("### Workflow State")
st.sidebar.write(st.session_state.workflow_state)

st.sidebar.markdown("---")


# -------------------------------
# HEADER
# -------------------------------

st.title("📊 AI BI Copilot")

st.caption("Semantic Modeling + KPI Generation + BI Automation")


# -------------------------------
# CREATE SESSION
# -------------------------------

if st.session_state.session_id is None:

    project_name = st.text_input(
        "Enter Project Name",
        placeholder="Retail Ecommerce Semantic Model"
    )

    if st.button("Start Project"):

        if not project_name.strip():
            st.warning("Please enter a project name")
            st.stop()

        response = requests.post(f"{API_BASE}/session")

        data = response.json()

        st.session_state.session_id = data["session_id"]
        st.session_state.workflow_state = data["state"]

        # Send first project message
        payload = {
            "message": project_name
        }

        r = requests.post(
            f"{API_BASE}/chat/{st.session_state.session_id}",
            json=payload
        )

        result = r.json()

        assistant_reply = result.get("reply",json.dumps(result, indent=2))
        st.session_state.messages.append({"role": "assistant","content": assistant_reply})

        st.session_state.workflow_state = result.get("state", st.session_state.workflow_state)

        st.rerun()


# -------------------------------
# CHAT AREA
# -------------------------------

for msg in st.session_state.messages:

    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])


# -------------------------------
# FILE UPLOAD
# -------------------------------

uploaded_files = st.file_uploader(
    "Upload Files",
    type=["csv", "xlsx"],
    accept_multiple_files=True
)

if uploaded_files and st.session_state.session_id:

    new_upload = False

    for file in uploaded_files:

        # Skip already uploaded files
        if file.name in st.session_state.uploaded_files:
            continue

        new_upload = True

        files = {
            "file": (
                file.name,
                file.getvalue(),
                "application/octet-stream"
            )
        }

        data = {
            "message": f"Uploading {file.name}"
        }

        try:

            response = requests.post(
                f"{API_BASE}/chat/{st.session_state.session_id}",
                files=files,
                data=data
            )

            result = response.json()

            assistant_reply = result.get(
                "reply",
                json.dumps(result, indent=2)
            )

            st.session_state.messages.append({
                "role": "assistant",
                "content": assistant_reply
            })

            st.session_state.workflow_state = result.get(
                "state",
                st.session_state.workflow_state
            )

            # Mark uploaded
            st.session_state.uploaded_files.add(file.name)

        except Exception as e:

            st.session_state.messages.append({
                "role": "assistant",
                "content": f"Upload Error: {str(e)}"
            })

    if new_upload:
        st.rerun()


# -------------------------------
# CHAT INPUT
# -------------------------------

if st.session_state.session_id:

    user_input = st.chat_input("Type your message...")

    if user_input is not None and user_input.strip() != "":

        # Show user message
        st.session_state.messages.append({
            "role": "user",
            "content": user_input
        })

        payload = {
            "message": user_input
        }

        try:

            response = requests.post(
                f"{API_BASE}/chat/{st.session_state.session_id}",
                json=payload
            )

            result = response.json()

            assistant_reply = result.get(
                "reply",
                json.dumps(result, indent=2)
            )

            st.session_state.messages.append({
                "role": "assistant",
                "content": assistant_reply
            })

            st.session_state.workflow_state = result.get(
                "state",
                st.session_state.workflow_state
            )

        except Exception as e:

            st.session_state.messages.append({
                "role": "assistant",
                "content": f"ERROR: {str(e)}"
            })

        st.rerun()

# -------------------------------
# EXPORTS
# -------------------------------

if st.session_state.workflow_state == "COMPLETE":

    st.markdown("---")
    st.subheader("Downloads")

    session_id = st.session_state.session_id

    excel_url  = f"{API_BASE}/export/{session_id}/excel"
    powerbi_url= f"{API_BASE}/export/{session_id}/powerbi"
    tmdl_url   = f"{API_BASE}/export/{session_id}/tmdl"
    report_url = f"{API_BASE}/export/{session_id}/report"

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"[⬇ Download Excel Workbook]({excel_url})")
        st.markdown(f"[⬇ Download Power BI Package (BIM + Report)]({powerbi_url})")
    with col2:
        st.markdown(f"[⬇ Download TMDL JSON]({tmdl_url})")
        st.markdown(f"[⬇ Download PDF Report]({report_url})")

    st.info(
        "**Power BI Package** contains:\n"
        "- `model.bim` — semantic model (tables, measures, DAX, relationships)\n"
        "- `report.json` — report layout with auto-generated visuals\n"
        "- `README_IMPORT.txt` — step-by-step import instructions for Power BI Desktop"
    )